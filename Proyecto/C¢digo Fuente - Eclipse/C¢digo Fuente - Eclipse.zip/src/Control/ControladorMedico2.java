package Control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

import javax.swing.*;

import Modelo.*;
import Vista.*;

/**
 *
 * @author APUS
 */
public class ControladorMedico2 implements ActionListener {

    public VentanaMedico2 ventanaControlada2;
    JFrame frmDialogo;
    public Medico usuarioMedico;
    public Paciente usuarioPaciente;

    //Funci�n controladora de la ventana de M�dico
    /**
     *
     * @param win
     * @param usuarioMedico
     * @param usuarioPaciente
     */
    public ControladorMedico2(VentanaMedico2 win, Medico usuarioMedico, Paciente usuarioPaciente) {
        ventanaControlada2 = win;
        this.usuarioMedico = usuarioMedico;
        this.usuarioPaciente = usuarioPaciente;
    }

    //Funci�n que indica las acciones que realizan los distintos objetos de la ventana
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(ventanaControlada2.btn_Medico_Atras)) {
            try {
                try {
                    abrirVentanaMedico1(usuarioMedico);
                } catch (Exception e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        } else if (e.getSource().equals(ventanaControlada2.btn_Medico_HistorialSesiones)) {
            try {
                try {
                    abrirVentanaSesiones(usuarioMedico, usuarioPaciente);
                } catch (Exception e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        } else if (e.getSource().equals(ventanaControlada2.btn_Medico_DarAlta)) {
            /*int respuesta = JOptionPane.showConfirmDialog( frmDialogo, "�Desea dar de alta a este paciente?", "Dar de Alta", JOptionPane.YES_NO_OPTION);
			if(respuesta == JOptionPane.YES_OPTION){
				Fichero fich = new Fichero();
				try {
					fich.darDeAlta(usuarioPaciente, ventanaControlada2, usuarioMedico);
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}*/
        }

    }

    /**
     *
     * @param usuario
     * @throws Exception
     */
    public void abrirVentanaMedico1(Medico usuario) throws Exception {
        ventanaControlada2.frmMedico2.dispose();
        VentanaMedico vp = new VentanaMedico();	//crea nueva ventana
        ControladorMedico cp = new ControladorMedico(vp, usuario);	//crea nuevo controlador de ventana
        vp.addController(cp);	//asigna el controlador a la ventana creada
        vp.crearVentana(usuario);
    }

    /**
     *
     * @param usuarioMedico
     * @param usuarioPaciente
     * @throws Exception
     */
    public void abrirVentanaSesiones(Medico usuarioMedico, Paciente usuarioPaciente) throws Exception {
        ventanaControlada2.frmMedico2.dispose();
        VentanaSesionesMedico vs = new VentanaSesionesMedico();
        ControladorSesionesMedico cs = new ControladorSesionesMedico(vs, usuarioMedico, usuarioPaciente);
        vs.addController(cs, usuarioPaciente);
        vs.crearVentana(usuarioMedico, usuarioPaciente);
    }
}
