package Control;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.SQLException;
import java.util.Date;
import java.util.Scanner;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import Vista.*;
import Modelo.*;

public class ControladorAnadirPaciente implements ActionListener {

    public VentanaAnadirPaciente ventanaControlada;
    public VentanaMedico ventanaMedico;
    boolean fotoComprobada = false;
    public static Medico dniMedico = null;
    public static Usuario us;

    JFrame frmDialogo;
    File selectedFile = null;

    //Funci�n controladora de la ventana de M�dico
    public ControladorAnadirPaciente(VentanaAnadirPaciente win, VentanaMedico win2, Medico usuarioMed) throws IOException {
        ventanaControlada = win;
        ventanaMedico = win2;
        dniMedico = usuarioMed;
        us = new Usuario();
    }

    //Funci�n que indica las acciones que realizan los distintos objetos de la ventana
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(ventanaControlada.btn_AP_Cancelar)) { //analiaza la acci�n en la ventana
            ventanaControlada.frmAnadirPaciente.dispose();//deja de hacerse visible la ventana cuando se pulsa el bot�n
            ventanaMedico.frmMedico.setEnabled(true);
        } else if (e.getSource().equals(ventanaControlada.btn_AP_BuscarImagen)) {
            final JFileChooser fc = new JFileChooser();
            int result = fc.showOpenDialog(ventanaControlada.btn_AP_BuscarImagen);
            if (result == JFileChooser.APPROVE_OPTION) {
                selectedFile = fc.getSelectedFile();
                if (Comprobar_Foto(selectedFile) == true) {
                    File archivoOrigen = new File(selectedFile.getPath());
                    fotoComprobada = true;
                    ventanaControlada.txt_AP_BuscarImagen.setText(archivoOrigen.getPath());
                }
            }
        } else if (e.getSource().equals(ventanaControlada.btn_AP_Aceptar)) {
            try {
                datosVentanaAPaciente();
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        }
    }

    private String getFileExtension(File file) {
        String name = file.getName();
        try {
            return name.substring(name.lastIndexOf(".") + 1);
        } catch (Exception e) {
            return "";
        }
    }

    public boolean Comprobar_Foto(File selectedFile) {
        boolean comprobado = false;
        if (selectedFile.isDirectory()) {
            comprobado = true;
        }
        String extension = getFileExtension(selectedFile);
        if (extension.equals("png") || extension.equals("jpg") || extension.equals("bmp") || extension.equals("jpeg")) {
            comprobado = true;
        } else {
            JFrame frame = new JFrame();
            JOptionPane.showMessageDialog((Component) frame, "Por favor, selecciona otra imagen.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return comprobado;
    }

    public static void abrirVentanaMedico(Medico usuarioMedico) throws IOException {
        VentanaMedico vm = new VentanaMedico();	//crea nueva ventana
        ControladorMedico cm = new ControladorMedico(vm, usuarioMedico);	//crea nuevo controlador de ventana
        vm.addController(cm);	//asigna el controlador a la ventana creada
        try {
            vm.crearVentana(usuarioMedico);
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
    }

    public void datosVentanaAPaciente() throws IOException {
        String dni = ventanaControlada.txt_AP_Dni.getText();
        String nombre = ventanaControlada.txt_AP_Nombre.getText();
        String apellidos = ventanaControlada.txt_AP_Apellidos.getText();
        String email = ventanaControlada.txt_AP_Email.getText();
        //String altura = ventanaControlada.txt_AP_Altura.getText();
        String altura = ventanaControlada.cb_AP_Altura.getActionCommand();
        String sexo = ventanaControlada.cb_AP_Sexo.getActionCommand();
        //String sexo = ventanaControlada.txt_AP_Sexo.getText();
        String calle = ventanaControlada.txt_AP_Direccion.getText();
        String provincia = ventanaControlada.txt_AP_Provincia.getText();
        String localidad = ventanaControlada.txt_AP_Localidad.getText();
        String cp = ventanaControlada.txt_AP_CP.getText();
        String telefono = ventanaControlada.txt_AP_Telefono.getText();
        //String foto = ventanaControlada.txt_AP_BuscarImagen.getText();

        if (nombre.isEmpty() || apellidos.isEmpty() || dni.isEmpty() || calle.isEmpty() || cp.isEmpty() || localidad.isEmpty() || provincia.isEmpty() || telefono.isEmpty()
                || email.isEmpty() || sexo.isEmpty() || altura.isEmpty()) {

            JOptionPane.showMessageDialog((Component) frmDialogo, "Faltan campos por rellenar.", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            JOptionPane.showConfirmDialog(frmDialogo, "�Guardar Cambios?", "Guardar nuevo paciente", JOptionPane.YES_NO_OPTION);

            Date nacimiento = ventanaControlada.dateChooser_AP_Nacimiento.getDate();
            Date inicio = ventanaControlada.dateChooser_AP_Inicio.getDate();

            String fechaN = String.valueOf(nacimiento);
            String fechaI = String.valueOf(inicio);

            Fichero nuevoPaciente = new Fichero();

            //TIPO 0: PACIENTE
            try {
                nuevoPaciente.guardarUsuario(dni, dni, 0);
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            Paciente pac = new Paciente(fechaI, fechaI, 0, 0, fechaI, fechaI, fechaI, fechaI, fechaI, fechaI, 0, fechaI, fechaI, fechaI, fechaI, fechaI, fechaI);

            nuevoPaciente.guardarPaciente(dni, nombre, apellidos, calle, cp, localidad, provincia, telefono, email,
                    sexo, altura, fechaI, fechaN);
            nuevoPaciente.guardarMedicoPaciente(dni, dniMedico.getId_usuario());

            ventanaControlada.frmAnadirPaciente.dispose();
            ventanaMedico.frmMedico.dispose();
            us = Fichero.comprobarUsuario(dniMedico.getNombreUsuario(), dniMedico.getContrasena());
            dniMedico = Fichero.busquedaMedico(us);
            abrirVentanaMedico(dniMedico);

        }
    }
}
