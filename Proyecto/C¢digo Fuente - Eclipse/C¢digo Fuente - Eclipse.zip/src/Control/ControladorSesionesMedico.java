package Control;

import static java.lang.Math.PI;
import static java.lang.Math.sin;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;

import Vista.*;
import Modelo.*;

public class ControladorSesionesMedico implements ActionListener, MouseListener {

    JFrame frmDialogo;

    public VentanaSesionesMedico ventanaControlada;
    public Paciente usuarioPaciente;
    public Medico usuarioMedico;
    public Sesion sesion;
    public Fichero sesionfichero;
    Vector<Sesion> sesiones;
    private volatile boolean[] flags;

    /* flags flags[0]=FrecuenciaCardiaca,flags[1]=OxigSangre,flags[2]=altitud,flags[3]=velocidad
   * 
     */

    /**
     *
     * @param win
     * @param usuarioMedico
     * @param usuarioPaciente
     */
    public ControladorSesionesMedico(VentanaSesionesMedico win, Medico usuarioMedico, Paciente usuarioPaciente) {
        ventanaControlada = win;
        this.usuarioMedico = usuarioMedico;
        this.usuarioPaciente = usuarioPaciente;
        flags = new boolean[4];
        for (int i = 0; i < 4; i++) {
            flags[i] = false;
        }
        Fichero datosses = new Fichero();
        try {
            sesiones = datosses.sesionesPaciente(usuarioPaciente);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    /**
     *
     * @param jFreeChart
     */
    public void repintarGraficas(JFreeChart jFreeChart) {
        ChartPanel chartPanel = new ChartPanel(jFreeChart);
        ventanaControlada.panel_graficas.removeAll();
        ventanaControlada.panel_graficas.add(chartPanel);
        ventanaControlada.panel_graficas.validate();
    }
    //Funci�n que indica las acciones que realizan los distintos objetos de la ventana

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(ventanaControlada.btn_Sesiones_Atras)) {
            try {
                abrirVentanaMedico2(usuarioMedico, usuarioPaciente);
            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        } else if (e.getSource().equals(ventanaControlada.btn_Sesiones_Comentario)) {
            if (sesion != null) {
                try {
                    abrirVentanaComentarioSesiones(usuarioMedico, usuarioPaciente, sesion);
                } catch (IOException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            } else {
                Object frame = null;
                JOptionPane.showMessageDialog((Component) frame, "Selecciona una sesion.", "Error", JOptionPane.ERROR_MESSAGE);	//sale una ventana de di�logo para alertar de un error
            }
        } else if (e.getSource().equals(ventanaControlada.btn_Sesiones_Altitud)) {
            if (flags[2] == true) {
                flags[2] = false;
            } else {
                flags[2] = true;
            }

            GraficaController grafica = new GraficaController(flags, sesion);
            repintarGraficas(grafica.getGrafica());

        } else if (e.getSource().equals(ventanaControlada.btn_Sesiones_Oxigeno)) {
            if (flags[1] == true) {
                flags[1] = false;
            } else {
                flags[1] = true;
            }

            GraficaController grafica = new GraficaController(flags, sesion);
            repintarGraficas(grafica.getGrafica());

        } else if (e.getSource().equals(ventanaControlada.btn_Sesiones_Pulso)) {
            if (flags[0] == true) {
                flags[0] = false;
            } else {
                flags[0] = true;
            }

            GraficaController grafica = new GraficaController(flags, sesion);
            repintarGraficas(grafica.getGrafica());

        } else if (e.getSource().equals(ventanaControlada.btn_Sesiones_Velocidad)) {
            if (flags[3] == true) {
                flags[3] = false;
            } else {
                flags[3] = true;
            }

            GraficaController grafica = new GraficaController(flags, sesion);
            repintarGraficas(grafica.getGrafica());

        } else if (e.getSource().equals(ventanaControlada.btn_Sesion_VisualizarNuevaSesion)) {
            try {
                abrirVentanaSesiones(usuarioMedico, usuarioPaciente);
            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        }
    }

    /**
     *
     * @param usuarioMedico
     * @param usuarioPaciente
     * @throws IOException
     */
    public void abrirVentanaSesiones(Medico usuarioMedico, Paciente usuarioPaciente) throws IOException {
        ventanaControlada.frmSesiones.dispose();
        VentanaSesionesMedico vs = new VentanaSesionesMedico();
        ControladorSesionesMedico cs = new ControladorSesionesMedico(vs, usuarioMedico, usuarioPaciente);
        vs.addController(cs, usuarioPaciente);
        vs.crearVentana(usuarioMedico, usuarioPaciente);
    }

    /**
     *
     * @param usuarioMedico
     * @param usuarioPaciente
     * @throws IOException
     */
    public void abrirVentanaMedico2(Medico usuarioMedico, Paciente usuarioPaciente) throws IOException {
        ventanaControlada.frmSesiones.dispose();//Cierra la ventana de inicio
        VentanaMedico2 vp = new VentanaMedico2();  //crea nueva ventana
        ControladorMedico2 cp = new ControladorMedico2(vp, usuarioMedico, usuarioPaciente);  //crea nuevo controlador de ventana
        vp.addController(cp);  //asigna el controlador a la ventana creada
        vp.crearVentana(usuarioMedico, usuarioPaciente);  //crea los elementos de la ventana
    }

    /**
     *
     * @param usuarioMedico
     * @param usuarioPaciente
     * @param sesion
     * @throws IOException
     */
    public void abrirVentanaComentarioSesiones(Medico usuarioMedico, Paciente usuarioPaciente, Sesion sesion) throws IOException {
        VentanaComentarioSesion vcs = new VentanaComentarioSesion();
        ControladorComentarioSesiones ccs = new ControladorComentarioSesiones(vcs);
        vcs.addController(ccs, sesion);
        vcs.crearVentana(usuarioPaciente, sesion);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getClickCount() == 2) {
            JTable target = (JTable) e.getSource();
            int row = target.getSelectedRow();
            try {
                sesion = Fichero.sesionRegistro(sesiones.get(row));
            } catch (IOException e1) {

                e1.printStackTrace();
            }
            String[] ini = sesion.getVectorTiempo().get(0).split(":");
            String[] fin = sesion.getVectorTiempo().get(sesion.getVectorTiempo().size() - 1).split(":");
            int segfin = Integer.parseInt(fin[0]) * 3600 + Integer.parseInt(fin[1]) * 60 + Integer.parseInt(fin[2]);
            int segini = Integer.parseInt(ini[0]) * 3600 + Integer.parseInt(ini[1]) * 60 + Integer.parseInt(ini[2]);
            double total = ((double) segfin - segini);
            int horas = (segfin - segini) / 3600;
            int minutos = (segfin - segini) / 60;
            double segundos = total % 60;
            ventanaControlada.lbl_Sesiones_Tiempo_Num.setText(String.valueOf(horas + "ڢ+minutos+\"'" + segundos + "''"));
            ventanaControlada.lbl_Sesiones_Tiempo_Num.repaint();

            ventanaControlada.lbl_Sesiones_Distancia_Num.setText(sesion.getDistancia().get(sesion.getDistancia().size() - 1).toString());
            ventanaControlada.lbl_Sesiones_Distancia_Num.repaint();
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mouseExited(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mousePressed(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mouseReleased(MouseEvent e) {
        // TODO Auto-generated method stub

    }
}
