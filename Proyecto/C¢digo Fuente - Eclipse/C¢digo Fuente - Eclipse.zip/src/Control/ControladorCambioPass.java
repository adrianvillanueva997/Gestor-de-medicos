package Control;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JOptionPane;

import Modelo.*;
import Vista.*;

public class ControladorCambioPass implements ActionListener {

    VentanaCambioPass ventanaControlada;
    public Usuario user;
    public String usuario;
    public String password;

    public ControladorCambioPass(VentanaCambioPass win, Usuario user) {
        ventanaControlada = win;
        this.user = user;
        this.usuario = user.getNombreUsuario();
        this.password = user.getContrasena();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(ventanaControlada.btn_CP_Cancelar)) {
            if (usuario.equals(password)) {
                Object frame = null;	//crea un objeto ventana
                JOptionPane.showMessageDialog((Component) frame, "Por motivos de seguridad, debe cambiar la contraseña.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                ventanaControlada.frmCambioPass.dispose();
            }
        }
        if (e.getSource().equals(ventanaControlada.btn_CP_Aceptar)) {
            try {
                cambioPass();
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        }
    }

    /**
     *
     * @param usuario
     * @throws Exception
     */
    public void abrirVentanas(Usuario usuario) throws Exception {
        try {
            Fichero comprobar = new Fichero();
            Usuario user = Fichero.comprobarUsuario(usuario.getNombreUsuario(), usuario.getContrasena());	//comprueba los datos introducidos
            switch (user.getTipoUsuario()) {
                case 0:
                    //Abre ventana Paciente
                    Paciente pac = comprobar.busquedaPaciente(user);
                    abrirVentanaPaciente(pac);
                    break;
                case 1:
                    //Abre ventana M�dico
                    Medico med = comprobar.busquedaMedico(user);
                    abrirVentanaMedico(med);
                    break;
                case 2:
                    //Abre ventana adminsitrador
                    Administrador admin = comprobar.busquedaAdministrador(user);
                    abrirVentanaAdmin(admin);
                    break;
            }
        } catch (IOException e1) {
            e1.printStackTrace();	//imprime el registro de la pila donde se dio la excepci�n
        }
    }

    /**
     *
     * @throws Exception
     */
    public void cambioPass() throws Exception {
        //String pass1 = ventanaControlada.ptxt_CP_Password.
        char caracteres1[] = ventanaControlada.ptxt_CP_Password.getPassword();	//array de caracteres que coge los elementos que se encuentran en el JPasswordField
        String password = String.valueOf(caracteres1);
        char caracteres2[] = ventanaControlada.ptxt_CP_VPassword.getPassword();	//array de caracteres que coge los elementos que se encuentran en el JPasswordField
        String password2 = String.valueOf(caracteres2);
        if (password.equals(password2)) {
            Fichero fich = new Fichero();
            fich.updatePassword(user.getId_usuario(), password);
            JOptionPane.showConfirmDialog(ventanaControlada, "¿Guardar Cambios?", "Cambiar Contraseña", JOptionPane.YES_NO_OPTION);
            //abrirVentanas(user);
            ventanaControlada.frmCambioPass.dispose();
        } else {
            Object frame = null;	//crea un objeto ventana
            JOptionPane.showMessageDialog((Component) frame, "Los campos no coinciden.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     *
     * @param usuarioPaciente
     * @throws Exception
     */
    public void abrirVentanaPaciente(Paciente usuarioPaciente) throws Exception {
        /**
         * Creaci�n de la ventana Paciente
         */
        ventanaControlada.frmCambioPass.setVisible(false);	//Cierra la ventana de inicio
        VentanaPaciente vp = new VentanaPaciente();	//crea nueva ventana
        ControladorPaciente cp = new ControladorPaciente(vp, usuarioPaciente);	//crea nuevo controlador de ventana
        vp.addController(cp);	//asigna el controlador a la ventana creada
        vp.crearVentana(usuarioPaciente);	//crea los elementos de la ventana
    }

    /**
     *
     * @param usuario
     * @throws Exception
     */
    public void abrirVentanaMedico(Medico usuario) throws Exception {
        /**
         * Creaci�n de la ventana M�dico
         */
        ventanaControlada.frmCambioPass.setVisible(false);	//Cierra la ventana de inicio
        VentanaMedico vm = new VentanaMedico();	//crea nueva ventana
        ControladorMedico cm = new ControladorMedico(vm, usuario);	//crea nuevo controlador de ventana
        vm.addController(cm);	//asigna el controlador a la ventana creada
        vm.crearVentana(usuario);	//crea los elementos de la ventana
    }

    /**
     *
     * @param usuario
     * @throws Exception
     */
    public void abrirVentanaAdmin(Administrador usuario) throws Exception {
        ventanaControlada.frmCambioPass.setVisible(false);
        VentanaAdmin va = new VentanaAdmin();
        ControladorAdmin cm = new ControladorAdmin(va, usuario);
        va.addController(cm);
        va.crearVentana(usuario);
    }
}
