package Control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.util.Vector;

import javax.swing.*;

import Modelo.*;
import Vista.*;

/**
 *
 * @author APUS
 */
public class ControladorAdmin implements ActionListener, MouseListener, KeyListener {

    public VentanaAdmin ventanaControlada;
    JFrame frmDialogo;
    JFrame frmDialogo2;
    public Administrador usuario;
    public Vector<Medico> medicos;

    //Funci�n controladora de la ventana de M�dico
    /**
     *
     * @param win
     * @param usuario
     */
    public ControladorAdmin(VentanaAdmin win, Administrador usuario) {
        ventanaControlada = win;
        this.usuario = usuario;
        this.medicos = new Vector<Medico>();
        Fichero datosMed = new Fichero();
        try {
            medicos = Fichero.adminMedicos(usuario);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    //Funci�n que indica las acciones que realizan los distintos objetos de la ventana
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(ventanaControlada.btn_Admin_Anadir_Medico)) {	//analiza la acci�n que se hace en la ventana y la iguala al btn_About
            abrirVentanaAnadirMedico();
        } else if (e.getSource().equals(ventanaControlada.btn_Admin_Cerrar_Sesion)) {

            int respuesta = JOptionPane.showConfirmDialog(frmDialogo, "�Desea cerrar sesion?", "Cerrar Sesion", JOptionPane.YES_NO_OPTION);

            if (respuesta == JOptionPane.YES_OPTION) {
                abrirVentanaIndex();
            }
        } else if (e.getSource().equals(ventanaControlada.btn_Admin_Buscar)) {
            try {
                buscarEnTabla();
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        } else if (e.getSource().equals(ventanaControlada.btn_CambiarPass)) {
            abrirCambiarPass();
        }
    }

    /**
     *
     */
    public void refrescarDatos() {
        Fichero datosMed = new Fichero();
        try {
            medicos = Fichero.adminMedicos(usuario);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    /**
     *
     * @return
     */
    public Vector<Medico> datosInicialesTablaAdmin() {

        return medicos;
    }

    public Vector<Medico> datosTablaAdmin() {
        Vector<Medico> medico = new Vector<>();
        try {
            medico = Fichero.adminMedicos(usuario);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return medico;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        /*if(e.getClickCount() == 2) {
			JTable target = (JTable) e.getSource();
            int row = target.getSelectedRow();
            
            try {
            	
				abrirVentanaMedico2(usuario,medicos.get(row) );
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}*/
    }

    @Override
    public void mouseEntered(MouseEvent arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mouseExited(MouseEvent arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mousePressed(MouseEvent arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mouseReleased(MouseEvent arg0) {
        // TODO Auto-generated method stub

    }

    /**
     *
     */
    public void abrirCambiarPass() {
        VentanaCambioPass vp = new VentanaCambioPass();
        ControladorCambioPass cp = new ControladorCambioPass(vp, usuario);
        vp.addController(cp);
        vp.CrearVentana(usuario);
    }

    /**
     *
     */
    public void abrirVentanaAnadirMedico() {
        VentanaAnadirMedico vap = new VentanaAnadirMedico();	//crea nueva ventana

        ControladorAnadirMedico cap = new ControladorAnadirMedico(vap, usuario);	//crea nuevo controlador de ventana

        vap.addController(cap);	//asigna el controlador a la ventana creada
        vap.crearVentana();
        ventanaControlada.frmAdmin.setEnabled(false);
    }

    /**
     *
     */
    public void abrirVentanaIndex() {
        ventanaControlada.frmAdmin.setVisible(false);
        VentanaIndex mainframe = new VentanaIndex();
        ControladorIndex mc = new ControladorIndex(mainframe);
        mainframe.addController(mc);
        mainframe.crearVentana();
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            try {
                buscarEnTabla();
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        }

    }

    @Override
    public void keyReleased(KeyEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void keyTyped(KeyEvent e) {
        // TODO Auto-generated method stub

    }

    /**
     *
     * @throws Exception
     */
    public void buscarEnTabla() throws Exception {
        String medicoBuscar = ventanaControlada.txt_Admin_Buscar.getText();
        Fichero datosPac = new Fichero();
        Vector<Medico> medicosTabla = null;
        try {
            medicosTabla = datosPac.adminMedicos(usuario);
        } catch (Exception e3) {
            // TODO Auto-generated catch block
            e3.printStackTrace();
        }

        Vector<Medico> medicosNuevos = new Vector<>();
        if (!(medicoBuscar.equals(""))) {
            try {
                medicosNuevos = datosPac.buscarMedicos(medicoBuscar);
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        } else {
            medicosNuevos = medicosTabla;
        }
        //ventanaControlada.remove(ventanaControlada.tabla_Admin);
        //ventanaControlada.repaint();

        ventanaControlada.tabla_Admin.remove(ventanaControlada.tabla_Admin);
        ventanaControlada.tabla_Admin.repaint();
        ventanaControlada.tabla_Admin.setModel(ventanaControlada.crearModeloTabla(ventanaControlada.tabla_Admin, medicosNuevos));

    }
}
