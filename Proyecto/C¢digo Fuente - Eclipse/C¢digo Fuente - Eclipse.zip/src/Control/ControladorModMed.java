package Control;

import java.awt.event.*;
import java.io.IOException;
import java.sql.SQLException;

import javax.swing.*;

import Modelo.*;
import Vista.*;

/**
 *
 * @author APUS
 */
public class ControladorModMed implements ActionListener {

    VentanaModMed ventanaControlada;

    /**
     *
     */
    public VentanaMedico ventana;
    JFrame frm = null;

    /**
     *
     */
    public Medico medico;

    /**
     *
     * @param win
     * @param medico
     */
    public ControladorModMed(VentanaModMed win, Medico medico) {
        ventanaControlada = win;
        this.medico = medico;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(ventanaControlada.btn_MM_Aceptar)) {
            try {
                datosMedico();
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        } else if (e.getSource().equals(ventanaControlada.btn_MM_Cancelar)) {
            ventanaControlada.frmAMed.dispose();
        }

    }

    /**
     *
     * @param usuario
     * @throws Exception
     */
    public void abrirVentanaMedico(Medico usuario) throws Exception {
        VentanaMedico va = new VentanaMedico();
        ControladorMedico cm = new ControladorMedico(va, usuario);
        va.addController(cm);
        va.crearVentana(usuario);
    }

    /**
     *
     * @throws Exception
     */
    public void datosMedico() throws Exception {
        Fichero fich = new Fichero();

        String dni = ventanaControlada.txt_MM_Dni.getText();
        String nombre = ventanaControlada.txt_MM_Nombre.getText();
        String apellidos = ventanaControlada.txt_MM_Apellidos.getText();
        String clinica = ventanaControlada.txt_MM_Clinica.getText();
        String n_colegiado = ventanaControlada.txt_MM_Colegiado.getText();

        if (dni.isEmpty() || nombre.isEmpty() || apellidos.isEmpty() || clinica.isEmpty() || n_colegiado.isEmpty()) {
            JOptionPane.showMessageDialog(frm, "Faltan campos por rellenar", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            JOptionPane.showConfirmDialog(frm, "�Guardar cambios?", "Guardar cambios", JOptionPane.YES_NO_OPTION);
            try {
                int nColegiado = Integer.parseInt(n_colegiado);
                fich.updateMed(medico.getId_usuario(), nombre, apellidos, clinica, nColegiado);
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            ventanaControlada.frmAMed.dispose();
            ventana.frmMedico.dispose();
            abrirVentanaMedico(medico);
        }

    }

}
