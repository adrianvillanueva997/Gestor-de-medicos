package Control;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

import Modelo.Fichero;
import Modelo.Paciente;
import Vista.*;

/**
 *
 * @author APUS
 */
public class ControladorFormularioSesion implements ActionListener {

    public VentanaFormularioSesion ventanaControlada;
    public VentanaPaciente ventanaPaciente;
    public Paciente usuarioPaciente;
    File selectedFile = null;
    public boolean csvComprobado = false;
    public String csv;
    public String comentario;
    public int estadoAnimo = 0;

    /**
     *
     * @param vp
     * @param win2
     * @param usuarioPaciente
     */
    public ControladorFormularioSesion(VentanaFormularioSesion vp, VentanaPaciente win2, Paciente usuarioPaciente) {
        ventanaControlada = vp;
        this.usuarioPaciente = usuarioPaciente;
        ventanaPaciente = win2;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(ventanaControlada.btn_Cancelar_SubirSesion)) { //analiaza la acci�n en la ventana
            ventanaControlada.frmSubirSesion.dispose();//deja de hacerse visible la ventana cuando se pulsa el bot�n
            ventanaPaciente.frmPaciente.setEnabled(true);
        } else if (e.getSource().equals(ventanaControlada.btn_Aceptar_SubirSesion)) {
            funcionVentana();

        } else if (e.getSource().equals(ventanaControlada.btn_Buscar_SubirSesion)) {
            final JFileChooser fc = new JFileChooser();
            int result = fc.showOpenDialog(ventanaControlada.btn_Buscar_SubirSesion);
            if (result == JFileChooser.APPROVE_OPTION) {
                selectedFile = fc.getSelectedFile();
                if (Comprobar_Csv(selectedFile) == true) {
                    csvComprobado = true;
                    ventanaControlada.txt_Buscar_SubirSesion.setText(selectedFile.getAbsolutePath());
                }
            }
        } else if (e.getSource().equals(ventanaControlada.btn_CaritaFeliz)) {
            estadoAnimo = 1;
        } else if (e.getSource().equals(ventanaControlada.btn_CaritaTriste)) {
            estadoAnimo = 2;
        } else if (e.getSource().equals(ventanaControlada.btn_CaritaNeutral)) {
            estadoAnimo = 3;
        }
    }

    private String getFileExtension(File file) {
        String name = file.getName();
        try {
            return name.substring(name.lastIndexOf(".") + 1);
        } catch (Exception e) {
            return "";
        }
    }

    /**
     *
     * @param selectedFile
     * @return
     */
    public boolean Comprobar_Csv(File selectedFile) {
        boolean comprobado = false;
        if (selectedFile.isDirectory()) {
            comprobado = true;
        }
        String extension = getFileExtension(selectedFile);
        if (extension.equals("csv")) {
            comprobado = true;
        } else {
            JFrame frame = new JFrame();
            JOptionPane.showMessageDialog((Component) frame, "Por favor, selecciona otro archivo.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return comprobado;
    }

    /**
     *
     * @param usuarioPaciente
     * @throws IOException
     */
    public void abrirVentanaPaciente(Paciente usuarioPaciente) throws IOException {
        VentanaPaciente vp = new VentanaPaciente();	//crea nueva ventana
        ControladorPaciente cp = new ControladorPaciente(vp, usuarioPaciente);	//crea nuevo controlador de ventana
        vp.addController(cp);	//asigna el controlador a la ventana creada
        vp.crearVentana(usuarioPaciente);	//crea los elementos de la ventana
    }

    /**
     *
     */
    public void funcionVentana() {

        String fecha = ventanaControlada.dateChooser.getDateFormatString();
        String pesoS = ventanaControlada.txt_Formulario_Peso.getText();
        if (ventanaControlada.txt_Buscar_SubirSesion.getText().isEmpty() || estadoAnimo == 0 || ventanaControlada.txtPn_Comentario_SubirSesion.getText().isEmpty()) {
            Object frame = null;
            JOptionPane.showMessageDialog((Component) frame, "Faltan campos por rellenar.", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            String path = ventanaControlada.txt_Buscar_SubirSesion.getText();
            String comentario = ventanaControlada.txtPn_Comentario_SubirSesion.getText();
            Fichero fich = new Fichero();
            double peso = Double.parseDouble(pesoS);
            double imc = imc(peso);
            fich.guardarSesion(usuarioPaciente.getId_usuario(), fecha, peso, estadoAnimo, comentario, imc);
            try {
                List<String[]> datosXlsx = fich.leerCsv(path);
                fich.parches(usuarioPaciente.getId_usuario(), datosXlsx);
                //fich.guardarDatosCSV(datosCSV, pathNuevo, comentario, estadoAnimo, dia, mes, ano, peso);
                //fich.guardarRegistros(usuarioPaciente.getId_usuario(), datosXlsx);

            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            ventanaControlada.frmSubirSesion.dispose();
            ventanaPaciente.frmPaciente.setEnabled(true);
        }
    }

    /**
     *
     * @param peso
     * @return
     */
    public double imc(double peso) {
        double altura = usuarioPaciente.getAltura() * usuarioPaciente.getAltura();
        double imc = peso / altura;
        return imc;
    }
}
