package Control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;

import Modelo.*;
import Vista.*;

/**
 *
 * @author APUS
 */
public class ControladorMedico implements ActionListener, MouseListener, KeyListener {

    /**
     *
     */
    public VentanaMedico ventanaControlada;
    JFrame frmDialogo;
    JFrame frmDialogo2;

    /**
     *
     */
    public Medico usuarioMedico;
    Vector<Paciente> pacientes;

    //Funci�n controladora de la ventana de M�dico
    /**
     *
     * @param win
     * @param usuario
     */
    public ControladorMedico(VentanaMedico win, Medico usuario) {
        ventanaControlada = win;
        usuarioMedico = usuario;
        this.pacientes = new Vector<Paciente>();
        Fichero datosPac = new Fichero();
        try {
            pacientes = datosPac.pacientesMedico(usuarioMedico);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    //Funci�n que indica las acciones que realizan los distintos objetos de la ventana
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(ventanaControlada.btn_Medico_Anadir_Paciente)) {	//analiza la acci�n que se hace en la ventana y la iguala al btn_About
            try {
                abrirVentanaAnadirPaciente();
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        } else if (e.getSource().equals(ventanaControlada.btn_Medico_Cerrar_Sesion)) {
            int respuesta = JOptionPane.showConfirmDialog(frmDialogo, "�Desea cerrar sesi�n?", "Cerrar Sesi�n", JOptionPane.YES_NO_OPTION);
            if (respuesta == JOptionPane.YES_OPTION) {
                try {
                    abrirVentanaIndex();
                } catch (Exception e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            }
        } else if (e.getSource().equals(ventanaControlada.btn_Medico_Buscar)) {
            try {
                buscarEnTabla();
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        } else if (e.getSource().equals(ventanaControlada.btn_Medico_Editar)) {

            try {
                abrirVentanaModMed(usuarioMedico);
            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }

            try {
                abrirVentanaModMed(usuarioMedico);
            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }

        } else if (e.getSource().equals(ventanaControlada.btn_CambiarPass)) {
            abrirCambiarPass();
        }
    }

    /*public Vector<Paciente> buscarPaciente(Paciente pacienteBuscar, Vector<Paciente> listadoTablaPacientes) throws IOException {
		Fichero datosPacientes = new Fichero();
		Vector<Paciente> listadoNuevo = new Vector<>();//String[listadoTablaPacientes.length][listadoTablaPacientes[0].length];
		listadoTablaPacientes = datosPacientes.pacientesMedico(usuarioMedico);
		int tamano = listadoTablaPacientes.size();
		
		//listadoNuevo = listadoTablaPacientes.;
		
		int contador = 0;	
		boolean encontrado = false;
		for(int i= 0; i<listadoNuevo.size(); i++) {	
			
			
				if (listadoTablaPacientes[i][j].toLowerCase().contains(pacienteBuscar.toLowerCase()) == true && pacienteBuscar.length()<=listadoTablaPacientes[i][j].length()){
					encontrado = true;
					listadoNuevo[contador] = datosPacientes.obtenerDatosPaciente(listadoTablaPacientes[i][0]);
					contador++;
			}
		}
		if (encontrado==false) {
			JOptionPane.showMessageDialog(frmDialogo2,"Paciente no encontrado.", "Error", JOptionPane.WARNING_MESSAGE);
		}
		return listadoNuevo;
	}*/
    /**
     *
     * @return
     */
    public Vector<Paciente> datosInicialesTablaMedico() {

        return pacientes;
    }

    /**
     *
     * @return
     */
    public Vector<Paciente> datosTablaMedico() {
        Vector<Paciente> pacientes = new Vector<>();
        Fichero datosPac = new Fichero();
        try {
            pacientes = datosPac.pacientesMedico(usuarioMedico);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return pacientes;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getClickCount() == 2) {
            JTable target = (JTable) e.getSource();
            int row = target.getSelectedRow();

            try {

                abrirVentanaMedico2(usuarioMedico, pacientes.get(row));
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        }
    }

    @Override
    public void mouseEntered(MouseEvent arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mouseExited(MouseEvent arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mousePressed(MouseEvent arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mouseReleased(MouseEvent arg0) {
        // TODO Auto-generated method stub

    }

    /**
     *
     */
    public void abrirCambiarPass() {
        VentanaCambioPass vp = new VentanaCambioPass();
        ControladorCambioPass cp = new ControladorCambioPass(vp, usuarioMedico);
        vp.addController(cp);
        vp.CrearVentana(usuarioMedico);
    }

    /**
     *
     * @throws Exception
     */
    public void abrirVentanaAnadirPaciente() throws Exception {

        VentanaAnadirPaciente vap = new VentanaAnadirPaciente();	//crea nueva ventana
        ControladorAnadirPaciente cap = new ControladorAnadirPaciente(vap, ventanaControlada, usuarioMedico);	//crea nuevo controlador de ventana
        vap.addController(cap);	//asigna el controlador a la ventana creada
        vap.crearVentana();
        ventanaControlada.frmMedico.setEnabled(false);
    }

    /**
     *
     * @throws Exception
     */
    public void abrirVentanaIndex() throws Exception {
        ventanaControlada.frmMedico.setVisible(false);
        VentanaIndex mainframe = new VentanaIndex();
        ControladorIndex mc = new ControladorIndex(mainframe);
        mainframe.addController(mc);
        mainframe.crearVentana();
    }

    /**
     *
     * @param usuarioMedico
     * @param usuarioPaciente
     * @throws IOException
     */
    public void abrirVentanaMedico2(Medico usuarioMedico, Paciente usuarioPaciente) throws IOException {
        ventanaControlada.frmMedico.dispose();//Cierra la ventana de inicio
        VentanaMedico2 vp = new VentanaMedico2();	//crea nueva ventana
        ControladorMedico2 cp = new ControladorMedico2(vp, usuarioMedico, usuarioPaciente);	//crea nuevo controlador de ventana
        vp.addController(cp);	//asigna el controlador a la ventana creada
        vp.crearVentana(usuarioMedico, usuarioPaciente);	//crea los elementos de la ventana
    }

    /**
     *
     * @param med
     * @throws IOException
     */
    public void abrirVentanaModMed(Medico med) throws IOException {

        VentanaModMed vm = new VentanaModMed();
        ControladorModMed cm = new ControladorModMed(vm, med);
        vm.addController(cm);
        vm.crearVentana(med);
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            try {
                buscarEnTabla();
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        }

    }

    @Override
    public void keyReleased(KeyEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void keyTyped(KeyEvent e) {
        // TODO Auto-generated method stub

    }

    /**
     *
     * @throws Exception
     */
    public void buscarEnTabla() throws Exception {
        String pacienteBuscar = ventanaControlada.txt_Medico_Buscar.getText();
        Fichero datosPac = new Fichero();
        Vector<Paciente> pacientesTabla = null;
        try {
            pacientesTabla = datosPac.pacientesMedico(usuarioMedico);
        } catch (Exception e3) {
            // TODO Auto-generated catch block
            e3.printStackTrace();
        }

        Vector<Paciente> pacientesNuevos = new Vector<>();
        if (!(pacienteBuscar.equals(""))) {
            try {
                pacientesNuevos = datosPac.buscarPaciente(pacienteBuscar);
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        } else {
            pacientesNuevos = pacientesTabla;
        }

        ventanaControlada.remove(ventanaControlada.tabla_Medico);
        ventanaControlada.repaint();
        ventanaControlada.tabla_Medico.setModel(ventanaControlada.crearModeloTabla(ventanaControlada.tabla_Medico, pacientesNuevos));

    }
}
