package Control;

import java.awt.Color;
import java.util.Vector;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import Modelo.Sesion;

/**
 *
 * @author adrian
 * @param <T>
 */
public class GraficaController<T> {

    boolean[] flags;
    Sesion sesion;
    JFreeChart grafica;
    XYDataset datos;

    /**
     *
     * @param flag
     * @param ses
     */
    public GraficaController(boolean[] flag, Sesion ses) {

        flags = flag;
        sesion = ses;
        datos = crearDatos(0, ses.getVectorTiempo().size());
        grafica = createChart(datos);

    }

    /**
     *
     * @param i
     * @return
     */
    private Vector<T> vectorMostrar(int i) {// Funcion ayuda vector deseado
        Vector<T> aux = null;
        switch (i) {
            case 0:
                aux = (Vector<T>) sesion.getVectorPulsacion();
                break;
            case 1:
                aux = (Vector<T>) sesion.getVectorSaturacion();
                break;
            case 2:
                aux = (Vector<T>) sesion.getVectorAltitud();
                break;
            case 3:
                aux = ((Vector<T>) sesion.getVectorVelocidad());
                break;
        }
        return aux;
    }

    /**
     *
     * @param i
     * @return
     */
    private String fltoString(int i) {// Funcion ayuda titulo 
        String aux = null;
        switch (i) {
            case 0:
                aux = "Frecuencia Cardiaca";
                break;
            case 1:
                aux = "Oxigeno en Sangre";
                break;
            case 2:
                aux = "Altitud";
                break;
            case 3:
                aux = "Velocidad";
                break;
        }
        return aux;
    }

    /**
     *
     * @param ini
     * @param fin
     * @return
     */
    private XYDataset crearDatos(int ini, int fin) {// Creamos datos de las graficas
        XYSeriesCollection dataset = new XYSeriesCollection();
        for (int i = 0; i < flags.length; i++) {// Recorremos el array de flgs comprobando cual quermos activar
            if (flags[i] == true) {
                XYSeries series1 = new XYSeries(fltoString(i));// titulo de la serie
                for (int a = ini; a < fin; a++) {// Creamos la serie con la informacion del vector deseado
                    double aux = new Double(vectorMostrar(i).get(a).toString());
                    String[] hora = sesion.getVectorTiempo().get(a).split(":");
                    double aux1 = new Double(hora[0] + "." + hora[1] + hora[2]);
                    series1.add(aux1, aux);
                }
                dataset.addSeries(series1);	// Añadimos la serie a nuestra datos
            }

        }
        return dataset;
    }

    /**
     *
     * @param dataset
     * @return
     */
    public JFreeChart createChart(XYDataset dataset) {

        final JFreeChart chart = ChartFactory.createXYLineChart(
                "Data", // chart title
                "Time", // x axis label
                " ", // y axis label
                dataset // data

        );
        chart.setBackgroundPaint(Color.white);
        return chart;
    }

    /**
     *
     * @return
     */
    public JFreeChart getGrafica() {
        return grafica;
    }
}
