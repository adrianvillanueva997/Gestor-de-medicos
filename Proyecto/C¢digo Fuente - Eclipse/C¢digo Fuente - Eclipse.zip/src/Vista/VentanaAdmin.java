package Vista;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import Control.*;
import Modelo.*;

/**
 *
 * @author APUS
 */
public class VentanaAdmin {

    ControladorAdmin controlador;
    public JFrame frmAdmin;
    public JLabel lbl_Admin_Rectangulo_Superior;
    public JTable tabla_Admin;
    public JButton btn_Admin_Anadir_Medico;
    public JTextField txt_Admin_Buscar;
    public JButton btn_Admin_Cerrar_Sesion;
    public JLabel lbl_Admin_Nombre;
    public JLabel lbl_Admin_Numero;
    public JLabel lbl_Logo_Admin_Slim;
    public JButton btn_Admin_Buscar;
    public JButton btn_CambiarPass;

    /**
     *
     * @param mc
     */
    public void addController(ControladorAdmin mc) {
        controlador = mc;
    }

    //Funci�n para crear la ventana y sus componentes
    /**
     *
     * @param usuario
     * @throws Exception
     */
    public void crearVentana(Administrador usuario) throws Exception {

        //crea la ventana
        frmAdmin = new JFrame();
        frmAdmin.setIconImage(Toolkit.getDefaultToolkit().getImage(("." + File.separator + "img" + File.separator + "apus_logo.jpg")));
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();	//Busca la resoluci�n de la pantalla
        frmAdmin.getContentPane().setBackground(Color.WHITE);
        frmAdmin.setBounds(0, 0, screen.width, screen.height);	//Establece dimensiones de la ventana
        frmAdmin.setExtendedState(JFrame.MAXIMIZED_BOTH);	//Maximiza por defecto la ventana
        frmAdmin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	//Estabalece la operaci�n de cierre por defecto
        frmAdmin.getContentPane().setLayout(null);	//obtiene el del contenido del JFrame y no establece ning�n tipo de Dise�o(Layout)
        frmAdmin.addKeyListener(controlador);

        //LABEL RECT�NGULO SUPERIOR:
        lbl_Admin_Rectangulo_Superior = new JLabel("");
        lbl_Admin_Rectangulo_Superior.setForeground(new Color(0, 0, 0));
        lbl_Admin_Rectangulo_Superior.setBackground(new Color(153, 0, 0));
        lbl_Admin_Rectangulo_Superior.setBorder(new LineBorder(new Color(153, 0, 0), 3));
        lbl_Admin_Rectangulo_Superior.setBounds(AnchoRelativo(0), AltoRelativo(0), AnchoRelativo(1943), AltoRelativo(98));
        frmAdmin.getContentPane().add(lbl_Admin_Rectangulo_Superior);

        Fichero comprobar = new Fichero();
        Administrador Admin = comprobar.busquedaAdministrador(usuario);

        lbl_Admin_Nombre = new JLabel(Admin.getNombreUsuario());
        lbl_Admin_Nombre.setFont(new Font("Tahoma", Font.PLAIN, fuenteRelativa(20)));
        lbl_Admin_Nombre.setBounds(AnchoRelativo(1417), AltoRelativo(16), AnchoRelativo(371), AltoRelativo(33));
        lbl_Admin_Nombre.setHorizontalAlignment(JLabel.RIGHT);
        frmAdmin.getContentPane().add(lbl_Admin_Nombre);

        //LABEL LOGO SLIMUE:
        lbl_Logo_Admin_Slim = new JLabel("");
        lbl_Logo_Admin_Slim.setBounds(AnchoRelativo(15), AltoRelativo(0), AnchoRelativo(321), AltoRelativo(98));
        Image logo_Admin_SlimUE = new ImageIcon(("." + File.separator + "img" + File.separator + "logo.png")).getImage();
        logo_Admin_SlimUE = logo_Admin_SlimUE.getScaledInstance(lbl_Logo_Admin_Slim.getWidth(), lbl_Logo_Admin_Slim.getHeight(), java.awt.Image.SCALE_SMOOTH);
        lbl_Logo_Admin_Slim.setIcon(new ImageIcon(logo_Admin_SlimUE));
        frmAdmin.getContentPane().add(lbl_Logo_Admin_Slim);

        //TABLA PACIENTES:		
        tabla_Admin = new JTable();
        Vector<Medico> data = controlador.datosInicialesTablaAdmin();
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setBounds(AnchoRelativo(248), AltoRelativo(288), AnchoRelativo(1424), AltoRelativo(550));
        scrollPane.setViewportView(tabla_Admin);
        crearModeloTabla(tabla_Admin, data);
        tabla_Admin.setBorder(new LineBorder(new Color(0, 0, 0)));
        tabla_Admin.setFont(new Font("Tahoma", Font.PLAIN, fuenteRelativa(20)));
        tabla_Admin.getTableHeader().setFont(new Font("Tahoma", Font.BOLD, fuenteRelativa(24)));
        tabla_Admin.setRowHeight((scrollPane.getHeight()) / 10);
        tabla_Admin.setAutoCreateRowSorter(true);

        tabla_Admin.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); //A�ade la libreria
        tabla_Admin.addMouseListener((MouseListener) controlador);

        tabla_Admin.setVisible(true);
        frmAdmin.getContentPane().add(scrollPane);

        //BOT�N A�ADIR PACIENTE:
        btn_Admin_Anadir_Medico = new JButton("");
        btn_Admin_Anadir_Medico.setOpaque(true);
        btn_Admin_Anadir_Medico.setBorder(new LineBorder(new Color(153, 0, 0), 2, true));
        btn_Admin_Anadir_Medico.setBounds(AnchoRelativo(82), AltoRelativo(245), AnchoRelativo(85), AltoRelativo(85));
        Image icono_anadir_paciente = new ImageIcon("." + File.separator + "img" + File.separator + "anadir_paciente.png").getImage();
        icono_anadir_paciente = icono_anadir_paciente.getScaledInstance(btn_Admin_Anadir_Medico.getWidth(), btn_Admin_Anadir_Medico.getHeight(), Image.SCALE_SMOOTH);
        btn_Admin_Anadir_Medico.setIcon(new ImageIcon(icono_anadir_paciente));
        frmAdmin.getContentPane().add(btn_Admin_Anadir_Medico);
        btn_Admin_Anadir_Medico.addActionListener(controlador);

        // BOT�N Cerrar_Sesion:
        btn_Admin_Cerrar_Sesion = new JButton("");
        btn_Admin_Cerrar_Sesion.addActionListener(controlador);
        btn_Admin_Cerrar_Sesion.setBounds(AnchoRelativo(1803), AltoRelativo(0), AnchoRelativo(126), AltoRelativo(98));
        btn_Admin_Cerrar_Sesion.setBorder(new LineBorder(new Color(153, 0, 0), 3));
        btn_Admin_Cerrar_Sesion.setForeground(new Color(153, 0, 0));
        btn_Admin_Cerrar_Sesion.setBackground(new Color(192, 192, 192));
        Image icono_apagar = new ImageIcon("." + File.separator + "img" + File.separator + "apagar.png").getImage();
        icono_apagar = icono_apagar.getScaledInstance(btn_Admin_Cerrar_Sesion.getWidth(), btn_Admin_Cerrar_Sesion.getHeight(), Image.SCALE_SMOOTH);
        btn_Admin_Cerrar_Sesion.setIcon(new ImageIcon(icono_apagar));
        frmAdmin.getContentPane().add(btn_Admin_Cerrar_Sesion);

        //TEXTFIELD BUSCAR:
        txt_Admin_Buscar = new JTextField();
        txt_Admin_Buscar.setBounds(AnchoRelativo(1257), AltoRelativo(197), AnchoRelativo(415), AltoRelativo(56));
        txt_Admin_Buscar.setFont(new Font("Tahoma", Font.PLAIN, fuenteRelativa(20)));
        txt_Admin_Buscar.setColumns(10);
        txt_Admin_Buscar.addKeyListener(controlador);
        frmAdmin.getContentPane().add(txt_Admin_Buscar);

        //BOTON BUSCAR:
        btn_Admin_Buscar = new JButton("");
        btn_Admin_Buscar.addActionListener(controlador);
        btn_Admin_Buscar.setBounds(AnchoRelativo(1173), AltoRelativo(197), AnchoRelativo(60), AltoRelativo(56));
        Image icono_buscar = new ImageIcon("." + File.separator + "img" + File.separator + "buscar.png").getImage();
        icono_buscar = icono_buscar.getScaledInstance(btn_Admin_Buscar.getWidth(), btn_Admin_Buscar.getHeight(), Image.SCALE_SMOOTH);
        btn_Admin_Buscar.setIcon(new ImageIcon(icono_buscar));
        btn_Admin_Buscar.setBackground(Color.WHITE);
        btn_Admin_Buscar.setBorderPainted(false);
        frmAdmin.getContentPane().add(btn_Admin_Buscar);

        btn_CambiarPass = new JButton("");
        btn_CambiarPass.setBorder(new LineBorder(new Color(139, 0, 0)));
        btn_CambiarPass.setBackground(Color.WHITE);
        btn_CambiarPass.setBounds(AnchoRelativo(15), AltoRelativo(774), AnchoRelativo(94), AltoRelativo(94));
        Image icono_CambioPass = new ImageIcon(("." + File.separator + "img" + File.separator + "pass.png")).getImage();
        icono_CambioPass = icono_CambioPass.getScaledInstance(btn_CambiarPass.getWidth(), btn_CambiarPass.getHeight(), Image.SCALE_SMOOTH);
        btn_CambiarPass.setIcon(new ImageIcon(icono_CambioPass));
        frmAdmin.getContentPane().add(btn_CambiarPass);
        btn_CambiarPass.addActionListener(controlador);

        frmAdmin.setVisible(true);		//Se hace visible la ventana
    }

    /**
     *
     * @param tabla_Admin
     * @param datos
     * @return
     * @throws Exception
     */
    public TableModel crearModeloTabla(JTable tabla_Admin, Vector<Medico> datos) throws Exception {
        tabla_Admin.removeAll();

        String[] nombre_Columnas_Admin = {"DNI", "Nombre", "Apellido"};

        TableModel modelo_Tabla_Admin = new DefaultTableModel(crearDatostabla(datos), nombre_Columnas_Admin) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tabla_Admin.setModel(modelo_Tabla_Admin);
        tabla_Admin.repaint();

        return modelo_Tabla_Admin;
    }

    /**
     *
     * @param datos
     * @return
     */
    public Object[][] crearDatostabla(Vector<Medico> datos) {
        Object[][] md = new Object[datos.size()][3];

        for (int i = 0; i < datos.size(); i++) {
            md[i][0] = datos.get(i).getDNI();
            md[i][1] = datos.get(i).getNombre();
            md[i][2] = datos.get(i).getApellido();

        }
        return md;
    }

    /**
     *
     * @param altura
     * @return
     */
    public int AltoRelativo(int altura) {
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        int AltoRelat = (screen.height * altura) / 1080;
        return AltoRelat;
    }

    /**
     *
     * @param ancho
     * @return
     */
    public int AnchoRelativo(int ancho) {
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        int AnchoRelat = (screen.width * ancho) / 1920;

        return AnchoRelat;
    }

    /**
     *
     * @param fuenteActual
     * @return
     */
    public int fuenteRelativa(int fuenteActual) {
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        int fuenteBuena = (screen.width * fuenteActual) / 1920;
        return fuenteBuena;
    }

}
