package Modelo;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

public class divide {

    public static Usuario comprobarUsuario(String usuario, String Password) throws IOException {	// BUsqueda de usuarios log-in
        Boolean busqueda = false;

        Connection c = null;
        Statement stmt = null;
        String pass;
        int tipous = 0;
        String name = " ";
        int id = 0;
        Usuario us = new Usuario();
        try {

            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM USUARIO;");

            while (rs.next() && (!busqueda)) {	//inicia b�squeda del usuario
                id = rs.getInt("ID_USUARIO");
                name = rs.getString("NICK");

                if (usuario.equals(name)) {
                    pass = rs.getString("PASS");
                    if (pass.equals(Password)) {
                        tipous = rs.getInt("TIPOUSER");

                        us.setId_usuario(id);
                        us.setTipoUsuario(tipous);
                        us.setContrasena(Password);
                        us.setNombreUsuario(name);
                        busqueda = true;
                    }
                }
            }
            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
        if (busqueda == true) {

            return us;
        } else {
            return null;
        }
    }

    public static Usuario compUsuario(int id_usuario) throws IOException {	// Devuelve un usuario a partir de un id_usuario
        Boolean busqueda = false;

        Connection c = null;
        Statement stmt = null;
        String pass;
        int tipous = 0;
        String name = " ";
        int id = 0;
        Usuario us = new Usuario();
        try {

            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM USUARIO where id_usuario like " + id_usuario + " ;");

            while (rs.next() && (!busqueda)) {	//inicia b�squeda del usuario
                id = rs.getInt("ID_USUARIO");
                name = rs.getString("NICK");
                pass = rs.getString("PASS");
                tipous = rs.getInt("TIPOUSER");

                us.setId_usuario(id);
                us.setTipoUsuario(tipous);
                us.setContrasena(pass);
                us.setNombreUsuario(name);
                busqueda = true;
            }

            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
        if (busqueda == true) {

            return us;
        } else {
            return null;
        }
    }

    public static Medico busquedaMedico(Usuario us) {// busqueda de medico a partir de un usuario

        Connection c = null;
        Statement stmt = null;

        Medico med = null;
        try {
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM MEDICO where ID_USUARIO like " + us.getId_usuario() + " ;");

            while (rs.next()) {	//inicia busqueda del medico
                String DNI = rs.getString("DNIM");
                String nombre = rs.getString("NOMBRE");
                String apellido = rs.getString("APELLIDOS");
                String clinica = rs.getString("CLINICA");
                int numeroColegiado = rs.getInt("N_COLEGIADO");

                med = new Medico(us.getNombreUsuario(), us.getContrasena(), us.getId_usuario(), us.getTipoUsuario(), DNI, nombre, apellido, clinica, numeroColegiado);

            }

            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        return med;

    }

    public static Paciente busquedaPaciente(Usuario us) { // busqueda de paciente a partir de un usuario

        Connection c = null;
        Statement stmt = null;
        Paciente pac = null;
        try {
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM PACIENTE where ID_USUARIO like " + us.getId_usuario() + ";");

            while (rs.next()) {	//inicia busqueda de pacientes
                String dnip = rs.getString("DNIP");
                String nombre = rs.getString("NOMBRE");
                String apellido = rs.getString("APELLIDOS");
                String email = rs.getString("EMAIL");
                String fechaNacimiento = rs.getString("FECHA DE NACIMIENTO");
                String fechaInicio = rs.getString("FECHA DE INICIO");
                int altura = rs.getInt("ALTURA");
                String sexo = rs.getString("SEXO");
                String calle = rs.getString("CALLE");
                String provincia = rs.getString("PROVINCIA");
                String localidad = rs.getString("LOCALIDAD");
                String CP = rs.getString("CP");
                String telefono = rs.getString("TELEFONO");
                pac = new Paciente(us.getNombreUsuario(), us.getContrasena(), us.getId_usuario(), us.getTipoUsuario(), dnip, nombre, apellido,
                        email, fechaNacimiento, fechaInicio, altura, sexo, calle, provincia, localidad, CP, telefono);
            }
            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        return pac;

    }

    public static Vector<Paciente> pacientesMedico(Medico med) {// Paciente asociados a un medico

        Connection c = null;
        Statement stmt = null;
        Paciente pac = null;
        Vector<Paciente> vectPaciente = new Vector<Paciente>();
        try {
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM MEDICO_PACIENTE  where ID_UsuarioMed like " + med.getId_usuario() + ";");

            while (rs.next()) {	//inicia b�squeda del usuario
                int ID_UsuarioPac = rs.getInt("ID_UsuarioPac");
                Usuario us = compUsuario(ID_UsuarioPac);
                Paciente pacient = busquedaPaciente(us);
                vectPaciente.add(pacient);
            }
            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        return vectPaciente;

    }

    public static Vector<Sesion> sesionesFecha(Paciente pac, String fecha) throws IOException {//Sesiones a partir de de un paciente y una fecha( sintaxis 00/00/0000)

        Connection c = null;
        Statement stmt = null;
        Sesion ses = null;
        Vector<Sesion> vectSesiones = new Vector<Sesion>();
        try {
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT* FROM SESIONES where ID_USUARIO like " + pac.getId_usuario() + " and FECHA like " + "'" + fecha + "'" + " ;");

            while (rs.next()) {	//inicia b�squeda del usuario
                int id_sesion = rs.getInt("ID_SESIONES");
                int peso = rs.getInt("PESO");
                String fech = rs.getString("FECHA");
                int estado = rs.getInt("ESTADO");
                String comentario = rs.getString("COMENTARIO");
                int imc = rs.getInt("IMC");

                ses = new Sesion(id_sesion, pac.getId_usuario(), peso, fech, estado, comentario, imc);
                vectSesiones.add(ses);
            }
            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        return vectSesiones;
    }

    public static Sesion sesionRegistro(Sesion ses) throws IOException { // Cargado de registro en la sesion correspondiente

        Connection c = null;
        Statement stmt = null;
        Vector<String> vectorTiempo = new Vector<String>();
        Vector<Float> vectorAltitud = new Vector<Float>();
        Vector<Float> vectorSaturacion = new Vector<Float>();
        Vector<Float> vectorPulsacion = new Vector<Float>();
        Vector<Float> vectorVelocidad = new Vector<Float>();
        Vector<Float> vectorLatitud = new Vector<Float>();
        Vector<Float> vectorLongitud = new Vector<Float>();
        Vector<Float> vectorDistancia = new Vector<Float>();

        try {
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM REGISTRO where ID_SESIONES like " + ses.getId_sesion() + ";");

            while (rs.next()) {	//inicia b�squeda del usuario
                String tiempo = rs.getString("TIME");
                float latitud = rs.getFloat("LATITUDE");
                float longitud = rs.getFloat("LONGITUDE");
                float altitud = rs.getFloat("ALTITUDE");
                float velocidad = rs.getFloat("SPEED");
                float distancia = rs.getFloat("DISTANCE");
                float pulsaciones = rs.getFloat("PULSACIONES");
                float spo2 = rs.getFloat("SpO2");
                vectorTiempo.add(tiempo);
                vectorLatitud.add(latitud);
                vectorLongitud.add(longitud);
                vectorAltitud.add(altitud);
                vectorVelocidad.add(velocidad);
                vectorDistancia.add(distancia);
                vectorPulsacion.add(pulsaciones);
                vectorSaturacion.add(spo2);
            }
            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
        ses.setVectorAltitud(vectorAltitud);
        ses.setDistancia(vectorDistancia);
        ses.setVectorLongitud(vectorLongitud);
        ses.setVectorPulsacion(vectorPulsacion);
        ses.setVectorSaturacion(vectorSaturacion);
        ses.setVectorTiempo(vectorTiempo);
        ses.setVectorVelocidad(vectorVelocidad);
        ses.setVectorLatitud(vectorLatitud);

        return ses;
    }

    public static Sesion sesionRegHora(Sesion ses, String horaInicio, String horaFin) throws IOException {
        Connection c = null;
        Statement stmt = null;
        Vector<String> vectorTiempo = new Vector<String>();
        Vector<Float> vectorAltitud = new Vector<Float>();
        Vector<Float> vectorSaturacion = new Vector<Float>();
        Vector<Float> vectorPulsacion = new Vector<Float>();
        Vector<Float> vectorVelocidad = new Vector<Float>();
        Vector<Float> vectorLatitud = new Vector<Float>();
        Vector<Float> vectorLongitud = new Vector<Float>();
        Vector<Float> vectorDistancia = new Vector<Float>();

        try {
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM REGISTRO where ID_SESIONES like " + ses.getId_sesion() + " and time between " + "'" + horaInicio + "'" + " and " + "'" + horaFin + "'" + " ;");

            while (rs.next()) {	//inicia b�squeda del usuario
                String tiempo = rs.getString("TIME");
                float latitud = rs.getFloat("LATITUDE");
                float longitud = rs.getFloat("LONGITUDE");
                float altitud = rs.getFloat("ALTITUDE");
                float velocidad = rs.getFloat("SPEED");
                float distancia = rs.getFloat("DISTANCE");
                float pulsaciones = rs.getFloat("PULSACIONES");
                float spo2 = rs.getFloat("SpO2");
                vectorTiempo.add(tiempo);
                vectorLatitud.add(latitud);
                vectorLongitud.add(longitud);
                vectorAltitud.add(altitud);
                vectorVelocidad.add(velocidad);
                vectorDistancia.add(distancia);
                vectorPulsacion.add(pulsaciones);
                vectorSaturacion.add(spo2);
            }
            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
        ses.setVectorAltitud(vectorAltitud);
        ses.setDistancia(vectorDistancia);
        ses.setVectorLongitud(vectorLongitud);
        ses.setVectorPulsacion(vectorPulsacion);
        ses.setVectorSaturacion(vectorSaturacion);
        ses.setVectorTiempo(vectorTiempo);
        ses.setVectorVelocidad(vectorVelocidad);
        ses.setVectorLatitud(vectorLatitud);

        return ses;
    }

    public static Administrador busquedaAdministrador(Usuario us) {
        Connection c = null;
        Statement stmt = null;

        Administrador admin = null;
        try {
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM ADMINISTRADOR where ID_USUARIO like " + us.getId_usuario() + " ;");

            while (rs.next()) {	//inicia busqueda del medico
                int id_administrador = rs.getInt("ID_ADMINISTRADOR");
                admin = new Administrador(us.getNombreUsuario(), us.getContrasena(), us.getId_usuario(), us.getTipoUsuario(), id_administrador);

            }

            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        return admin;

    }

    public static Administrador adminMedicos(Administrador admin) {

        Connection c = null;
        Statement stmt = null;

        Vector<Medico> vectMed = new Vector<Medico>();
        try {
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM MEDICO ;");

            while (rs.next()) {	//inicia b�squeda del usuario
                String DNI = rs.getString("DNIM");
                int id_medico = rs.getInt("ID_USUARIO");
                String nombre = rs.getString("NOMBRE");
                String apellido = rs.getString("APELLIDOS");
                String clinica = rs.getString("CLINICA");
                int numeroColegiado = rs.getInt("N_COLEGIADO");
                Medico medi = new Medico(id_medico, DNI, nombre, apellido, clinica, numeroColegiado);
                vectMed.add(medi);
            }
            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        admin.setVectMedicos(vectMed);
        return admin;
    }

    public static void main(String[] args) throws InterruptedException, IOException {
        Usuario user = null;
        user = comprobarUsuario("11001", "11001");
        switch (user.getTipoUsuario()) {//Paciente 0 Medico 1 Administrador2
            case 0:
                Paciente pc = busquedaPaciente(user);
                Sesion sesi;
                Vector<Sesion> ses = sesionesFecha(pc, "21/05/2017");
                System.out.println(ses.get(0).getId_sesion());
                sesi = sesionRegHora(ses.get(0), "13:26:21", "13:28:00");
                break;
            case 1:
                Medico me = busquedaMedico(user);
                System.out.println(me.getNombre());
                Vector<Paciente> pac = pacientesMedico(me);
                break;
            case 2:
                Administrador adm = busquedaAdministrador(user);
                adm = adminMedicos(adm);
                break;
        }

    }
}
