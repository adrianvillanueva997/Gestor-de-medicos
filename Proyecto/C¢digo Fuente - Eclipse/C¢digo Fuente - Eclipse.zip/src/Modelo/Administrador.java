package Modelo;

import java.util.Vector;

/**
 *
 * @author APUS
 */
public class Administrador extends Usuario {

    /**
     *
     */
    private int id_administrador;

    /**
     *
     */
    private Vector<Medico> vectMedicos;

    /**
     * @param nombreUsuario
     * @param contrasena
     * @param tipoUsuario
     * @param id_usuario
     * @param id_administrator
     */
    public Administrador(String nombreUsuario, String contrasena, int id_usuario, int tipoUsuario, int id_administrador) {
        super(nombreUsuario, contrasena, id_usuario, tipoUsuario);
        this.id_administrador = id_administrador;

    }

    /**
     *
     * @return
     */
    public int getId_administrador() {
        return id_administrador;
    }

    /**
     *
     * @param id_administrador
     */
    public void setId_administrador(int id_administrador) {
        this.id_administrador = id_administrador;
    }

    /**
     *
     * @return
     */
    public Vector<Medico> getVectMedicos() {
        return vectMedicos;
    }

    /**
     *
     * @param vectMedicos
     */
    public void setVectMedicos(Vector<Medico> vectMedicos) {
        this.vectMedicos = vectMedicos;
    }
}
