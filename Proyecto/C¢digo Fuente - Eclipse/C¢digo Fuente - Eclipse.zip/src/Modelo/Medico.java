package Modelo;

/**
 *
 * @author APUS
 */
public class Medico extends Usuario {

    private String DNI;
    private String nombre;
    private String apellido;
    private String clinica;
    private int numeroColegiado;

    /**
     * @param nombreUsuario
     * @param contrasena
     * @param id_usuario
     * @param tipoUsuario
     * @param dNI
     * @param nombre
     * @param apellido
     * @param clinica
     * @param numeroColegiado
     */
    public Medico(String nombreUsuario, String contrasena, int id_usuario, int tipoUsuario, String dNI, String nombre, String apellido,
            String clinica, int numeroColegiado) {
        super(nombreUsuario, contrasena, id_usuario, tipoUsuario);
        DNI = dNI;
        this.nombre = nombre;
        this.apellido = apellido;
        this.clinica = clinica;
        this.numeroColegiado = numeroColegiado;
    }

    /**
     *
     * @param id_usuario
     * @param dNI
     * @param nombre
     * @param apellido
     * @param clinica
     * @param numeroColegiado
     */
    public Medico(int id_usuario, String dNI, String nombre, String apellido,
            String clinica, int numeroColegiado) {
        this.setId_usuario(id_usuario);
        DNI = dNI;
        this.nombre = nombre;
        this.apellido = apellido;
        this.clinica = clinica;
        this.numeroColegiado = numeroColegiado;
    }

    /**
     *
     */
    public Medico() {

    }

    /**
     *
     * @param dNI
     * @param nombre
     * @param apellido
     * @param clinica
     * @param numeroColegiado
     */
    public Medico(String dNI, String nombre, String apellido, String clinica, int numeroColegiado) {
        DNI = dNI;
        this.nombre = nombre;
        this.apellido = apellido;
        this.clinica = clinica;
        this.numeroColegiado = numeroColegiado;
    }

    /**
     * @return the dNI
     */
    public String getDNI() {
        return DNI;
    }

    /**
     * @param dNI the dNI to set
     */
    public void setDNI(String dNI) {
        DNI = dNI;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the apellido
     */
    public String getApellido() {
        return apellido;
    }

    /**
     * @param apellido the apellido to set
     */
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    /**
     * @return the clinica
     */
    public String getClinica() {
        return clinica;
    }

    /**
     * @param clinica the clinica to set
     */
    public void setClinica(String clinica) {
        this.clinica = clinica;
    }

    /**
     * @return the numeroColegiado
     */
    public int getNumeroColegiado() {
        return numeroColegiado;
    }

    /**
     * @param numeroColegiado the numeroColegiado to set
     */
    public void setNumeroColegiado(int numeroColegiado) {
        this.numeroColegiado = numeroColegiado;
    }

}
