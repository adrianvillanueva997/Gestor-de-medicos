package Modelo;

import java.awt.Component;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;

import javax.swing.JOptionPane;

import Control.*;
import Vista.*;

/**
 *
 * @author APUS
 */
public class Fichero {

    /*BufferedWriter escritor;
	BufferedReader lector;//crea un lector de fichero
	BufferedReader lector1;//crea un lector de fichero
	File ficheroUsuario = new File("FicheroUsuario.txt");
	File ficheroPacientes= new File("FicheroPacientes.txt");
	File ficheroMedico = new File("FicheroMedico.txt");
	File ficheroMedicoPaciente = new File("FicheroMedicoPaciente.txt");
	String p = ";";*/
    /**
     *
     */
    private Vector<String> vectorTiempo = new Vector<>();

    /**
     *
     */
    private Vector<Float> vectorAltitud = new Vector<>();

    /**
     *
     */
    private Vector<Float> vectorSaturacion = new Vector<>();

    /**
     *
     */
    private Vector<Float> vectorPulsacion = new Vector<>();

    /**
     *
     */
    private Vector<Float> vectorVelocidad = new Vector<>();

    /**
     *
     */
    private Vector<Float> vectorLatitud = new Vector<>();

    /**
     *
     */
    private Vector<Float> vectorLongitud = new Vector<>();

    /**
     *
     */
    private Vector<Float> vectorDistancia = new Vector<>();

    //Función para comprobar si el usuario pertenece al fichero abierto
    /**
     *
     * @param usuario
     * @param Password
     * @return
     * @throws IOException
     */
    public static Usuario comprobarUsuario(String usuario, String Password) throws IOException {	// BUsqueda de usuarios log-in
        Boolean busqueda = false;

        Connection c = null;
        Statement stmt = null;
        String pass;
        int tipous = 0;
        String name = " ";
        int id = 0;
        Usuario us = new Usuario();
        try {

            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM USUARIO;");

            while (rs.next() && (!busqueda)) {	//inicia b�squeda del usuario
                id = rs.getInt("ID_USUARIO");
                name = rs.getString("NICK");

                if (usuario.equals(name)) {
                    pass = rs.getString("PASS");
                    if (pass.equals(Password)) {
                        tipous = rs.getInt("TIPOUSER");

                        us.setId_usuario(id);
                        us.setTipoUsuario(tipous);
                        us.setContrasena(Password);
                        us.setNombreUsuario(name);
                        busqueda = true;
                    }
                }
            }
            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
        if (busqueda == true) {
            return us;
        } else {
            return null;
        }

    }

    /**
     *
     * @param id_usuario
     * @return
     * @throws IOException
     */
    public static Usuario compUsuario(int id_usuario) throws IOException {	// Devuelve un usuario a partir de un id_usuario
        Boolean busqueda = false;

        Connection c = null;
        Statement stmt = null;
        String pass;
        int tipous = 0;
        String name = " ";
        int id = 0;
        Usuario us = new Usuario();
        try {

            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM USUARIO where id_usuario like " + id_usuario + " ;");

            while (rs.next() && (!busqueda)) {	//inicia b�squeda del usuario
                id = rs.getInt("ID_USUARIO");
                name = rs.getString("NICK");
                pass = rs.getString("PASS");
                tipous = rs.getInt("TIPOUSER");

                us.setId_usuario(id);
                us.setTipoUsuario(tipous);
                us.setContrasena(pass);
                us.setNombreUsuario(name);
                busqueda = true;
            }

            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
        if (busqueda == true) {

            return us;
        } else {
            return null;
        }
    }

    public void guardarUsuario(String nick, String password, int tipoUsuario) throws SQLException {

        System.out.println("Insertando Valores Usuario...\n");

        Connection dbConnection = null;
        PreparedStatement preparedStatement = null;

        String insertUsuario = "INSERT INTO USUARIO"
                + "(NICK,PASS,TIPOUSER) VALUES"
                + "(?,?,?)";

        try {
            dbConnection = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            preparedStatement = dbConnection.prepareStatement(insertUsuario);

            preparedStatement.setString(1, nick);
            preparedStatement.setString(2, password);
            preparedStatement.setInt(3, tipoUsuario);

            preparedStatement.execute();
            System.out.println("¡Datos de Usuario correctamente guardados!\n");
        } catch (Exception e) {

            System.out.println(e.getMessage());

        } finally {

            if (preparedStatement != null) {
                preparedStatement.close();
            }

            if (dbConnection != null) {
                dbConnection.close();
            }
        }

    }

    /**
     *
     * @param dni
     * @param nombre
     * @param apellidos
     * @param n_colegiado
     * @param clinica
     * @throws SQLException
     */
    public void guardarMedico(String dni, String nombre, String apellidos, String n_colegiado, String clinica) throws SQLException {
        System.out.println("Insertando Valores Medicos...\n");

        Connection dbConnection = null;
        PreparedStatement preparedStatement = null;
        Statement stmt = null;

        try {
            dbConnection = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            stmt = dbConnection.createStatement();
            ResultSet select = stmt.executeQuery("SELECT ID_USUARIO FROM USUARIO WHERE NICK = '" + dni + "'");
            int idUsuario = Integer.parseInt(select.getString("ID_USUARIO"));
            int colegiado = Integer.parseInt(n_colegiado);

            String insertMedico = "INSERT INTO MEDICO"
                    + "(DNIM,ID_USUARIO,NOMBRE,APELLIDOS,CLINICA,N_COLEGIADO,ACTIVIDAD) VALUES"
                    + "(?,?,?,?,?,?,?)";

            preparedStatement = dbConnection.prepareStatement(insertMedico);
            preparedStatement.setString(1, dni);
            preparedStatement.setInt(2, idUsuario);
            preparedStatement.setString(3, nombre);
            preparedStatement.setString(4, apellidos);
            preparedStatement.setString(5, clinica);
            preparedStatement.setInt(6, colegiado);
            preparedStatement.setInt(7, 1);
            preparedStatement.execute();
            System.out.println("¡Datos de Medicos correctamente guardados!\n");
        } catch (Exception e) {

            System.out.println(e.getMessage());

        } finally {

            if (preparedStatement != null) {
                preparedStatement.close();
            }

            if (dbConnection != null) {
                dbConnection.close();
            }
        }
    }

    /**
     *
     * @param dni
     * @param nombre
     * @param apellidos
     * @param calle
     * @param cp
     * @param localidad
     * @param provincia
     * @param telefono
     * @param email
     * @param sexo
     * @param altura
     * @param fechaInicio
     * @param fechaNacimiento
     */
    public void guardarPaciente(String dni, String nombre, String apellidos, String calle, String cp, String localidad, String provincia,
            String telefono, String email, String sexo, String altura, String fechaInicio, String fechaNacimiento) {

        System.out.println("Insertando Valores Paciente...\n");
        Connection dbConnection = null;
        Statement stmt = null;
        PreparedStatement preparedStatement = null;

        try {
            dbConnection = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            stmt = dbConnection.createStatement();
            ResultSet select = stmt.executeQuery("SELECT ID_USUARIO FROM USUARIO WHERE NICK = '" + dni + "'");
            int idUsuario = Integer.parseInt(select.getString("ID_USUARIO"));

            String insertPacientes = "INSERT INTO PACIENTE"
                    + "(DNIP,ID_USUARIO,NOMBRE,APELLIDOS,EMAIL,'FECHA DE NACIMIENTO','FECHA DE INICIO',ALTURA,SEXO,CALLE,PROVINCIA,LOCALIDAD,CP,TELEFONO,ACTIVIDAD) VALUES"
                    + "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

            /*String fechaNacimiento = diaNacimiento + "/" + mesNacimiento + "/" + anoNacimiento;
		    	String fechaInicio = diaInicio + "/" + mesInicio + "/" + anoInicio;*/
            //java.sql.Date inicio = java.sql.Date.valueOf(fechaInicio);
            //java.sql.Date nacimiento = java.sql.Date.valueOf(fechaNacimiento);
            int tlf = Integer.parseInt(telefono);
            int CP = Integer.parseInt(cp);

            preparedStatement = dbConnection.prepareStatement(insertPacientes);
            preparedStatement.setString(1, dni);
            preparedStatement.setInt(2, idUsuario);
            preparedStatement.setString(3, nombre);
            preparedStatement.setString(4, apellidos);
            preparedStatement.setString(5, email);
            preparedStatement.setString(6, fechaNacimiento);
            preparedStatement.setString(7, fechaInicio);
            preparedStatement.setString(8, altura);
            preparedStatement.setString(9, sexo);
            preparedStatement.setString(10, calle);
            preparedStatement.setString(11, provincia);
            preparedStatement.setString(12, localidad);
            preparedStatement.setInt(13, CP);
            preparedStatement.setInt(14, tlf);
            preparedStatement.setInt(15, 1);

            // execute the preparedstatement
            preparedStatement.execute();
            System.out.println("¡Datos de Pacientes correctamente guardados!\n");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {

            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            if (dbConnection != null) {
                try {
                    dbConnection.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        }
    }

    /**
     *
     * @param dniPaciente
     * @param idMedico
     */
    public void guardarMedicoPaciente(String dniPaciente, int idMedico) {

        System.out.println("Insertando Valores MEDICO-PACIENTE...\n");

        Connection dbConnection = null;
        PreparedStatement preparedStatement = null;
        Statement stmt = null;
        String insertMedicoPaciente = "INSERT INTO MEDICO_PACIENTE"
                + "(ID_MEDICO_PACIENTE,ID_UsuarioMed,ID_UsuarioPac) VALUES"
                + "(?,?,?)";

        try {

            dbConnection = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            stmt = dbConnection.createStatement();
            ResultSet select = stmt.executeQuery("SELECT ID_USUARIO FROM USUARIO WHERE NICK = '" + dniPaciente + "'");
            int idPaciente = Integer.parseInt(select.getString("ID_USUARIO"));

            preparedStatement = dbConnection.prepareStatement(insertMedicoPaciente);
            //preparedStatement.setString (1, );
            preparedStatement.setInt(2, idMedico);
            preparedStatement.setInt(3, idPaciente);

            // execute the preparedstatement
            preparedStatement.execute();
            System.out.println("¡Datos MEDICO-PACIENTE correctamente guardados!\n");
        } catch (Exception e) {

            System.out.println(e.getMessage());

        } finally {

            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }

            if (dbConnection != null) {
                try {
                    dbConnection.close();
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }

        }
    }

    /**
     *
     * @param idUser
     * @param fecha
     * @param peso
     * @param estado
     * @param comentario
     * @param imc
     */
    public void guardarSesion(int idUser, String fecha, double peso, int estado, String comentario, double imc) {
        System.out.println("Insertando Valores SESION...\n");

        Connection dbConnection = null;
        PreparedStatement preparedStatement = null;

        String insertMedicoPaciente = "INSERT INTO SESIONES"
                + "(ID_SESIONES,ID_USUARIO,PESO, FECHA, ESTADO, COMENTARIO, IMC) VALUES"
                + "(?,?,?,?,?,?,?)";

        try {

            String indice = String.valueOf(imc);

            dbConnection = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            preparedStatement = dbConnection.prepareStatement(insertMedicoPaciente);
            preparedStatement.setInt(2, idUser);
            preparedStatement.setDouble(3, peso);
            preparedStatement.setString(4, fecha);
            preparedStatement.setInt(5, estado);
            preparedStatement.setString(6, comentario);
            preparedStatement.setString(7, indice);

            // execute the preparedstatement
            preparedStatement.execute();
            System.out.println("¡Datos SESION correctamente guardados!\n");
        } catch (Exception e) {

            System.out.println(e.getMessage());

        } finally {

            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }

            if (dbConnection != null) {
                try {
                    dbConnection.close();
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }

        }
    }

    /**
     *
     * @param idUser
     * @param passNuevo
     */
    public void updatePassword(int idUser, String passNuevo) {
        System.out.println("Operacion de Actualizacion de PASSWORD");
        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            String sql = "UPDATE USUARIO set PASS = " + passNuevo + " where ID_USUARIO = " + idUser + ";";
            stmt.executeUpdate(sql);
            c.commit();

            ResultSet rs = stmt.executeQuery("SELECT * FROM USUARIO;");
            while (rs.next()) {
                int id = rs.getInt("ID_USUARIO");
                String nick = rs.getString("NICK");
                //int age  = rs.getInt("age");
                String password = rs.getString("PASS");
                int tipoUser = rs.getInt("TIPOUSER");
                //System.out.println( "ID_USUARIO:" + id + ", NICK: " + name + ", edad: " + age + ", dir: " + address + ", sal: " + salary);
            }
            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
        System.out.println("Actualizacion de PASSWORD realizada");
    }

    /**
     *
     * @param idUser
     * @param dni
     * @param nombre
     * @param apellidos
     * @param calle
     * @param cp
     * @param localidad
     * @param provincia
     * @param telefono
     * @param email
     * @param sexo
     * @param altura
     */
    public void updatePac(int idUser, String dni, String nombre, String apellidos, String calle, String cp, String localidad, String provincia,
            String telefono, String email, String sexo, String altura/*, int diaNacimiento, int mesNacimiento, int anoNacimiento,
				int diaInicio, int mesInicio, int anoInicio*/) {
        System.out.println("Operacion de Actualizacion de PACIENTE");
        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            String sql = "UPDATE PACIENTE set NOMBRE = " + nombre + ", APELLIDOS = " + apellidos + ",EMAIL  = " + email + ", ALTURA = " + altura + ", CALLE = " + calle
                    + ",LOCALIDAD = " + localidad + ", PROVINCIA = " + provincia + ", CP = " + cp + ", TELEFONO = " + telefono + " where ID_USUARIO = " + idUser + ";";
            stmt.executeUpdate(sql);
            c.commit();
            stmt.close();
            c.close();
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
        System.out.println("Actualizacion de PACIENTE realizada");
    }

    /**
     *
     * @param idUser
     * @param nombre
     * @param apellidos
     * @param clinica
     * @param nColegiado
     */
    public void updateMed(int idUser, String nombre, String apellidos, String clinica, int nColegiado) {
        System.out.println("Operacion de Actualizacion de MEDICO");
        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            String sql = "UPDATE MEDICO set NOMBRE = " + nombre + ", APELLIDOS = " + apellidos + ",CLINICA  = " + clinica + ", N_COLEGIADO = " + nColegiado + " where ID_USUARIO = " + idUser + ";";
            stmt.executeUpdate(sql);
            c.commit();
            stmt.close();
            c.close();
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
        System.out.println("Actualizacion de MEDICO realizada");
    }

    /**
     *
     * @param idUser
     */
    public void updateDelPac(int idUser) {
        System.out.println("'Borrando' paciente.");
        Connection c = null;
        Statement stmt = null;
        try {
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            String sql = "UPDATE PACIENTE SET ACTIVIDAD = 0 WHERE ID_USUARIO = " + idUser;
            stmt.executeUpdate(sql);
            c.commit();
            stmt.close();
            c.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Paciente borrado.");
    }

    /**
     *
     * @param idUser
     */
    public void updateDelMed(int idUser) {
        System.out.println("'Borrando' medico.");
        Connection c = null;
        Statement stmt = null;
        try {
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);

            stmt = c.createStatement();
            String sql = "UPDATE MEDICO SET ACTIVIDAD = 0 WHERE ID_USUARIO = " + idUser;
            stmt.executeUpdate(sql);
            c.commit();
            stmt.close();
            c.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Medico borrado.");
    }

    /**
     *
     * @param pac
     * @return
     * @throws IOException
     */
    public static Vector<Sesion> sesionesPaciente(Paciente pac) throws IOException {//Sesiones a partir de de un paciente y una fecha( sintaxis 00/00/0000)

        Connection c = null;
        Statement stmt = null;
        Sesion ses = null;
        Vector<Sesion> vectSesiones = new Vector<Sesion>();
        try {
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT* FROM SESIONES where ID_USUARIO like " + pac.getId_usuario() + " ;");

            while (rs.next()) {	//inicia bï¿½squeda del usuario
                int id_sesion = rs.getInt("ID_SESIONES");
                int peso = rs.getInt("PESO");
                String fech = rs.getString("FECHA");
                int estado = rs.getInt("ESTADO");
                String comentario = rs.getString("COMENTARIO");
                int imc = rs.getInt("IMC");

                ses = new Sesion(id_sesion, pac.getId_usuario(), peso, fech, estado, comentario, imc);
                vectSesiones.add(ses);
            }
            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        return vectSesiones;
    }

    /**
     *
     * @param us
     * @return
     */
    public static Medico busquedaMedico(Usuario us) {// busqueda de medico a partir de un usuario
        System.out.println("Haciendo un Select");
        Connection c = null;
        Statement stmt = null;

        Medico med = null;
        try {
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM MEDICO where ID_USUARIO like " + us.getId_usuario() + " ;");

            while (rs.next()) {	//inicia busqueda del medico
                String DNI = rs.getString("DNIM");
                String nombre = rs.getString("NOMBRE");
                String apellido = rs.getString("APELLIDOS");
                String clinica = rs.getString("CLINICA");
                int numeroColegiado = rs.getInt("N_COLEGIADO");

                med = new Medico(us.getNombreUsuario(), us.getContrasena(), us.getId_usuario(), us.getTipoUsuario(), DNI, nombre, apellido, clinica, numeroColegiado);

            }

            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        return med;

    }

    /**
     *
     * @param us
     * @return
     */
    public static Paciente busquedaPaciente(Usuario us) { // busqueda de paciente a partir de un usuario

        Connection c = null;
        Statement stmt = null;
        Paciente pac = null;
        try {
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM PACIENTE where ID_USUARIO like " + us.getId_usuario() + ";");

            while (rs.next()) {	//inicia busqueda de pacientes
                String dnip = rs.getString("DNIP");
                String nombre = rs.getString("NOMBRE");
                String apellido = rs.getString("APELLIDOS");
                String email = rs.getString("EMAIL");
                String fechaNacimiento = rs.getString("FECHA DE NACIMIENTO");
                String fechaInicio = rs.getString("FECHA DE INICIO");
                int altura = rs.getInt("ALTURA");
                String sexo = rs.getString("SEXO");
                String calle = rs.getString("CALLE");
                String provincia = rs.getString("PROVINCIA");
                String localidad = rs.getString("LOCALIDAD");
                String CP = rs.getString("CP");
                String telefono = rs.getString("TELEFONO");
                pac = new Paciente(us.getNombreUsuario(), us.getContrasena(), us.getId_usuario(), us.getTipoUsuario(), dnip, nombre, apellido,
                        email, fechaNacimiento, fechaInicio, altura, sexo, calle, provincia, localidad, CP, telefono);
            }
            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        return pac;

    }

    /**
     *
     * @param med
     * @return
     */
    public static Vector<Paciente> pacientesMedico(Medico med) {// Paciente asociados a un medico

        Connection c = null;
        Statement stmt = null;
        Paciente pac = null;
        Vector<Paciente> vectPaciente = new Vector<Paciente>();
        try {
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM MEDICO_PACIENTE  where ID_UsuarioMed like " + med.getId_usuario() + ";");

            while (rs.next()) {	//inicia b�squeda del usuario
                int ID_UsuarioPac = rs.getInt("ID_UsuarioPac");
                Usuario us = compUsuario(ID_UsuarioPac);
                Paciente pacient = busquedaPaciente(us);
                vectPaciente.add(pacient);
            }
            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        return vectPaciente;

    }

    /**
     *
     * @param pac
     * @param fecha
     * @return
     * @throws IOException
     */
    public static Vector<Sesion> sesionesFecha(Paciente pac, String fecha) throws IOException {//Sesiones a partir de de un paciente y una fecha( sintaxis 00/00/0000)

        Connection c = null;
        Statement stmt = null;
        Sesion ses = null;
        Vector<Sesion> vectSesiones = new Vector<Sesion>();
        try {
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT* FROM SESIONES where ID_USUARIO like " + pac.getId_usuario() + " and FECHA like " + "'" + fecha + "'" + " ;");

            while (rs.next()) {	//inicia b�squeda del usuario
                int id_sesion = rs.getInt("ID_SESIONES");
                int peso = rs.getInt("PESO");
                String fech = rs.getString("FECHA");
                int estado = rs.getInt("ESTADO");
                String comentario = rs.getString("COMENTARIO");
                int imc = rs.getInt("IMC");

                ses = new Sesion(id_sesion, pac.getId_usuario(), peso, fech, estado, comentario, imc);
                vectSesiones.add(ses);
            }
            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        return vectSesiones;
    }

    /**
     *
     * @param ses
     * @return
     * @throws IOException
     */
    public static Sesion sesionRegistro(Sesion ses) throws IOException { // Cargado de registro en la sesion correspondiente

        Connection c = null;
        Statement stmt = null;
        Vector<String> vectorTiempo = new Vector<String>();
        Vector<Float> vectorAltitud = new Vector<Float>();
        Vector<Float> vectorSaturacion = new Vector<Float>();
        Vector<Float> vectorPulsacion = new Vector<Float>();
        Vector<Float> vectorVelocidad = new Vector<Float>();
        Vector<Float> vectorLatitud = new Vector<Float>();
        Vector<Float> vectorLongitud = new Vector<Float>();
        Vector<Float> vectorDistancia = new Vector<Float>();

        try {
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM REGISTRO where ID_SESIONES like " + ses.getId_sesion() + ";");

            while (rs.next()) {	//inicia b�squeda del usuario
                String tiempo = rs.getString("TIME");
                float latitud = rs.getFloat("LATITUDE");
                float longitud = rs.getFloat("LONGITUDE");
                float altitud = rs.getFloat("ALTITUDE");
                float velocidad = rs.getFloat("SPEED");
                float distancia = rs.getFloat("DISTANCE");
                float pulsaciones = rs.getFloat("PULSACIONES");
                float spo2 = rs.getFloat("SpO2");
                vectorTiempo.add(tiempo);
                vectorLatitud.add(latitud);
                vectorLongitud.add(longitud);
                vectorAltitud.add(altitud);
                vectorVelocidad.add(velocidad);
                vectorDistancia.add(distancia);
                vectorPulsacion.add(pulsaciones);
                vectorSaturacion.add(spo2);
            }
            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
        ses.setVectorAltitud(vectorAltitud);
        ses.setDistancia(vectorDistancia);
        ses.setVectorLongitud(vectorLongitud);
        ses.setVectorPulsacion(vectorPulsacion);
        ses.setVectorSaturacion(vectorSaturacion);
        ses.setVectorTiempo(vectorTiempo);
        ses.setVectorVelocidad(vectorVelocidad);
        ses.setVectorLatitud(vectorLatitud);

        return ses;
    }

    /**
     *
     * @param us
     * @param ses
     * @return
     */
    public static String[] busquedaSesion(Paciente us, Sesion ses) {
        Connection c = null;
        Statement stmt = null;
        Paciente pac = null;
        String[] sesion = new String[7];
        try {
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM SESIONES where ID_USUARIO = " + us.getId_usuario() + " AND ID_SESIONES = " + ses.getId_sesion() + ";");

            while (rs.next()) {	//inicia busqueda de pacientes
                int idSesion = rs.getInt("ID_SESIONES");
                String iS = String.valueOf(idSesion);
                sesion[0] = iS;
                int idUsuario = rs.getInt("ID_USUARIO");
                String iU = String.valueOf(idUsuario);
                sesion[1] = iU;
                String peso = rs.getString("PESO");
                sesion[2] = peso;
                String fecha = rs.getString("FECHA");
                sesion[3] = fecha;
                int estado = rs.getInt("ESTADO");
                String est = String.valueOf(estado);
                sesion[4] = est;
                String comentario = rs.getString("COMENTARIO");
                sesion[5] = comentario;
                String imc = rs.getString("IMC");
                sesion[6] = imc;
            }
            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
        return sesion;
    }

    /**
     *
     * @param us
     * @return
     */
    public static Administrador busquedaAdministrador(Usuario us) {
        Connection c = null;
        Statement stmt = null;

        Administrador admin = null;
        try {
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM ADMINISTRADOR where ID_USUARIO like " + us.getId_usuario() + " ;");

            while (rs.next()) {	//inicia busqueda del medico
                int id_administrador = rs.getInt("ID_ADMINISTRADOR");
                admin = new Administrador(us.getNombreUsuario(), us.getContrasena(), us.getId_usuario(), us.getTipoUsuario(), id_administrador);

            }

            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        return admin;

    }

    /**
     *
     * @param admin
     * @return
     */
    public static Vector<Medico> adminMedicos(Administrador admin) {

        Connection c = null;
        Statement stmt = null;

        Vector<Medico> vectMed = new Vector<Medico>();
        try {
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM MEDICO ;");

            while (rs.next()) {	//inicia b�squeda del usuario
                String DNI = rs.getString("DNIM");
                int id_medico = rs.getInt("ID_USUARIO");
                String nombre = rs.getString("NOMBRE");
                String apellido = rs.getString("APELLIDOS");
                String clinica = rs.getString("CLINICA");
                int numeroColegiado = rs.getInt("N_COLEGIADO");
                Medico medi = new Medico(id_medico, DNI, nombre, apellido, clinica, numeroColegiado);
                vectMed.add(medi);
            }
            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        admin.setVectMedicos(vectMed);
        return vectMed;
    }

    /**
     *
     * @param sesionCSV
     * @return
     * @throws IOException
     */
    public List<String[]> leerCsv(String sesionCSV) throws IOException {
        List<String[]> datosCSV = new ArrayList<String[]>();
        BufferedReader br = new BufferedReader(new FileReader(sesionCSV));
        String linea;
        while ((linea = br.readLine()) != null) {
            String[] lineatxt = linea.split(";");
            datosCSV.add(lineatxt);
        }
        br.close();
        return datosCSV;
    }

    /**
     *
     * @param idUser
     * @param datosCsv
     */
    public void parches(int idUser, List<String[]> datosCsv) {
        Connection dbConnection = null;
        PreparedStatement preparedStatement = null;
        Statement stmt = null;
        String tiempo = null;
        float latitud = 0, longitud = 0, altitud = 0, distancia = 0, pulsacion = 0, velocidad = 0, saturacion = 0;
        try {

            dbConnection = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            stmt = dbConnection.createStatement();
            ResultSet select = stmt.executeQuery("SELECT ID_SESIONES FROM SESIONES WHERE ID_USUARIO like '" + idUser + "'");
            int idSesion = Integer.parseInt(select.getString("ID_SESIONES"));

            String insertMedicoPaciente = "INSERT INTO REGISTRO"
                    + "(ID_SESIONES,TIME,LATITUDE,LONGITUDE,ALTITUDE,SPEED,DISTANCE,SpO2) VALUES"
                    + "(?,?,?,?,?,?,?,?)";

            boolean encontrado = false;
            for (int i = 0; i < datosCsv.size(); i++) {
                int a = 0;
                preparedStatement = dbConnection.prepareStatement(insertMedicoPaciente);
                while (encontrado == false) {
                    if (datosCsv.get(i)[a].split(";") != null) {
                        switch (a % 8) {
                            case 0:
                                tiempo = datosCsv.get(i)[a];
                                break;
                            case 1:
                                String temp = datosCsv.get(i)[a];
                                latitud = Float.parseFloat(temp);
                                break;
                            case 2:
                                longitud = Float.parseFloat(datosCsv.get(i)[a]);
                                break;
                            case 3:
                                altitud = Float.parseFloat(datosCsv.get(i)[a]);
                                break;
                            case 4:
                                velocidad = Float.parseFloat(datosCsv.get(i)[a]);
                                break;
                            case 5:
                                distancia = Float.parseFloat(datosCsv.get(i)[a]);
                                break;
                            case 6:
                                pulsacion = Float.parseFloat(datosCsv.get(i)[a]);
                                break;
                            case 7:
                                saturacion = Float.parseFloat(datosCsv.get(i)[a]);
                                break;
                            case 8:
                                encontrado = true;
                                break;
                        }
                    }
                    a++;
                }
                preparedStatement.setInt(1, idSesion);
                preparedStatement.setString(2, tiempo);
                preparedStatement.setFloat(3, latitud);
                preparedStatement.setFloat(4, longitud);
                preparedStatement.setFloat(5, altitud);
                preparedStatement.setFloat(6, velocidad);
                preparedStatement.setFloat(7, distancia);
                preparedStatement.setFloat(8, pulsacion);
                preparedStatement.setFloat(9, saturacion);
                preparedStatement.execute();
            }
            System.out.println("insert realizado con exito");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {

            if (preparedStatement != null) {
                try {
                    stmt.close();
                    preparedStatement.close();
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }

            if (dbConnection != null) {
                try {
                    dbConnection.close();
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }

        }
    }

    /**
     *
     * @param busqueda
     * @return
     */
    public static Vector<Paciente> buscarPaciente(String busqueda) {
        Connection c = null;
        Statement stmt = null;
        Paciente pac = null;
        Vector<Paciente> vpacientes = new Vector<Paciente>();
        try {
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM PACIENTE where NOMBRE like " + "'%" + busqueda + "%' OR "
                    + "APELLIDOS like " + "'%" + busqueda + "%'" + " OR DNIP like " + "'%" + busqueda + "%'" + " ;");

            while (rs.next()) { //inicia busqueda de pacientes
                String dnip = rs.getString("DNIP");
                String nombre = rs.getString("NOMBRE");
                String apellido = rs.getString("APELLIDOS");
                String email = rs.getString("EMAIL");
                String fechaNacimiento = rs.getString("FECHA DE NACIMIENTO");
                String fechaInicio = rs.getString("FECHA DE INICIO");
                int altura = rs.getInt("ALTURA");
                String sexo = rs.getString("SEXO");
                String calle = rs.getString("CALLE");
                String provincia = rs.getString("PROVINCIA");
                String localidad = rs.getString("LOCALIDAD");
                String CP = rs.getString("CP");
                String telefono = rs.getString("TELEFONO");
                pac = new Paciente(dnip, nombre, apellido, email, fechaNacimiento, fechaInicio, altura, sexo, calle, provincia, localidad, CP, telefono);
                vpacientes.add(pac);
            }
            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        return vpacientes;

    }

    /**
     *
     * @param busqueda
     * @return
     */
    public static Vector<Medico> buscarMedicos(String busqueda) {// busqueda de medico a partir de un usuario
        System.out.println("Haciendo un Select");
        Connection c = null;
        Statement stmt = null;

        Vector<Medico> med = new Vector<>();
        Medico medico = null;
        try {
            c = DriverManager.getConnection("jdbc:sqlite:SlimUE.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM MEDICO where NOMBRE like " + "'%" + busqueda + "%' OR "
                    + "APELLIDOS like " + "'%" + busqueda + "%'" + " OR DNIM like " + "'%" + busqueda + "%'" + " ;");

            while (rs.next()) {	//inicia busqueda del medico
                String dni = rs.getString("DNIM");
                String nombre = rs.getString("NOMBRE");
                String apellido = rs.getString("APELLIDOS");
                String clinica = rs.getString("CLINICA");
                int numeroColegiado = rs.getInt("N_COLEGIADO");

                medico = new Medico(dni, nombre, apellido, clinica, numeroColegiado);
                med.add(medico);
            }

            rs.close();
            stmt.close();
            c.close();

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

        return med;

    }

    /*

	 public List<String[]> leerCSV (String sesionCSV) throws IOException {
		  List<String[]> datosCSV = new ArrayList<String[]>();
		  BufferedReader br = new BufferedReader(new FileReader(sesionCSV));
		  String linea;
		  while((linea=br.readLine())!=null){ 
		   String[] lineatxt= linea.split(";");
		   datosCSV.add(lineatxt);       
		  }
		  br.close();
		  return datosCSV;
	 }
		 
	 public void guardarDatosCSV(List<String[]> datosCSV, String nombreNuevoArch, String comentario, int estadoAnimo, int dia, int mes, int ano, String peso) throws IOException {
		  File datosSesion = new File(nombreNuevoArch);
		  escritor = new BufferedWriter(new FileWriter(datosSesion,true));
		  String estado = null;
		  switch(estadoAnimo) {
		   case 1: 
		    estado = "Feliz";
		    break;
		   case 2:
		    estado = "Triste";   
		    break;
		   case 3: 
		    estado = "Neutral";
		    break;
		  }
		  String distanciaRecorrida = datosCSV.get(datosCSV.size()-1)[5].toString();
		  String horaInicial = datosCSV.get(1)[0];
		  String horaFinal = datosCSV.get(datosCSV.size()-1)[0];
		  int horaSegundos = pasarHorasASegundos(horaFinal) - pasarHorasASegundos(horaInicial);
		  String horaTotal = pasarSegundosAHoras(horaSegundos);
		  escritor.write(dia +"/" + mes + "/" + ano + ";" + horaTotal + ";" + distanciaRecorrida);
		  escritor.newLine();
		  escritor.write("Estado: " + estado + p + "Peso: " + peso);
		  escritor.newLine();
		  escritor.write("Comentario: " + comentario);
		  escritor.newLine();
		  for (int i = 0; i < datosCSV.size();i++){
		   for(int j = 0; j < datosCSV.get(i).length;j++){
		    escritor.write(datosCSV.get(i)[j] + p);   
		   }
		   escritor.newLine();
		  }
		  escritor.close();
	}

	
	public String[][] leerSesionGrafica (String sesion) throws IOException {
		List<String[]> datosCSV = leerCSV(sesion);
		String[][] datosGraficas = new String[datosCSV.size()-4][5]; 
		// 0 - tiempo / 1 - velocidad / 2 - pulso / 3 - O2 / 4 - altitud 
		for(int i=4; i<datosCSV.size() ; i++) {
			datosGraficas[i-4][0] = datosCSV.get(i)[0];
			datosGraficas[i-4][1] = datosCSV.get(i)[4];
			datosGraficas[i-4][2] = datosCSV.get(i)[6];
			datosGraficas[i-4][3] = datosCSV.get(i)[7];
			datosGraficas[i-4][4] = datosCSV.get(i)[3];
		}		
		return datosGraficas;
	}
	
	public void borrarLinea(String usuario, File fichero, String nombreTemporal) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(fichero));
		File temporal = new File(nombreTemporal);
		BufferedWriter bw = new BufferedWriter(new FileWriter(temporal,true));
		String linea;
		String[] arrayLinea = null; 
		while((linea = br.readLine())!=null){
			arrayLinea = linea.split(";");
			if (!arrayLinea[0].equals(usuario)) {
				bw.write(linea);
				bw.newLine();
			}
			linea = null;
			arrayLinea = null; 
		}
		br.close();
		bw.close();
		String nombre = fichero.getName();
		fichero.delete();
		temporal.renameTo(new File(nombre));
				
	}
	
	public void darDeAlta(String usuarioPaciente, VentanaMedico2 win, String usuarioMedico) throws FileNotFoundException {
		String pathProject = System.getProperty("user.dir") + "\\Sesiones\\" + usuarioPaciente;
		File carpeta = new File(pathProject);
		ControladorMedico2 controlador = new ControladorMedico2(win, usuarioMedico, usuarioPaciente);
		try {
			borrarLinea(usuarioPaciente, ficheroUsuario, "temp1.txt");
			borrarLinea(usuarioPaciente, ficheroMedicoPaciente, "temp3.txt");
			if (carpeta.isDirectory()) {
				carpeta.delete();
			}
			controlador.abrirVentanaMedico1(usuarioMedico);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}*/
}
